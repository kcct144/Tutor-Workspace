import { l as likeValue } from './contracts.mjs';
import { m as executeWrite, A as ApiError } from './nitro.mjs';
import { t as taskAssignmentCounts } from './task-assignments.mjs';
import { w as writeAuditLog } from './audit.mjs';

const fields = "t.id,t.title,t.subject,t.description,t.status,t.version,t.created_at,t.updated_at,t.study_plan_id,p.title AS study_plan_title";
const joins = " FROM tasks t LEFT JOIN study_plan_documents p ON p.id=t.study_plan_id";
function projectTask(row) {
  var _a;
  return {
    id: String(row.id),
    title: row.title,
    subject: row.subject,
    description: row.description,
    status: row.status,
    version: row.version,
    createdAt: row.created_at.replace(" ", "T") + "Z",
    updatedAt: row.updated_at.replace(" ", "T") + "Z",
    assignmentCount: 0,
    studyPlan: row.study_plan_id ? { id: String(row.study_plan_id), title: (_a = row.study_plan_title) != null ? _a : "" } : null
  };
}
function filter(query, options = false) {
  const clauses = [], values = [];
  if (query.keyword) {
    clauses.push(
      "(t.title LIKE ? ESCAPE '!' OR t.subject LIKE ? ESCAPE '!' OR t.description LIKE ? ESCAPE '!')"
    );
    values.push(...Array(3).fill(likeValue(query.keyword)));
  }
  if (query.subject) {
    clauses.push("t.subject=?");
    values.push(query.subject);
  }
  if (options || query.status) {
    clauses.push("t.status=?");
    values.push(options ? "enabled" : query.status);
  }
  return {
    sql: clauses.length ? " WHERE " + clauses.join(" AND ") : "",
    values
  };
}
async function requirePlan(db, studyPlanId) {
  if (!studyPlanId) return;
  const [rows] = await db.execute(
    "SELECT id FROM study_plan_documents WHERE id=? LIMIT 1 FOR SHARE",
    [studyPlanId]
  );
  if (!rows.length)
    throw new ApiError(404, "NOT_FOUND", "\u672A\u627E\u5230\u5173\u8054\u7684\u5B66\u4E60\u8BA1\u5212\u3002");
}
function auditSummary(task) {
  var _a, _b;
  return {
    title: task.title,
    subject: task.subject,
    status: task.status,
    studyPlanId: (_b = (_a = task.studyPlan) == null ? void 0 : _a.id) != null ? _b : null
  };
}
async function listTasks(db, query, options = false) {
  const where = filter(query, options);
  const [count] = await db.execute(
    "SELECT COUNT(*) AS total FROM tasks t" + where.sql + " LIMIT 1",
    where.values
  );
  const [rows] = await db.execute(
    "SELECT " + (options ? "t.id,t.title,t.subject,t.study_plan_id,p.title AS study_plan_title" : fields) + joins + where.sql + " ORDER BY t.updated_at DESC,t.id DESC LIMIT ? OFFSET ?",
    [...where.values, query.pageSize, (query.page - 1) * query.pageSize]
  );
  const counts = options ? /* @__PURE__ */ new Map() : await taskAssignmentCounts(
    db,
    rows.map((row) => String(row.id))
  );
  return {
    items: options ? rows.map((row) => {
      var _a;
      return {
        id: String(row.id),
        title: row.title,
        subject: row.subject,
        studyPlan: row.study_plan_id ? {
          id: String(row.study_plan_id),
          title: (_a = row.study_plan_title) != null ? _a : ""
        } : null
      };
    }) : rows.map((row) => {
      var _a;
      return {
        ...projectTask(row),
        assignmentCount: (_a = counts.get(String(row.id))) != null ? _a : 0
      };
    }),
    total: Number(count[0].total),
    page: query.page,
    pageSize: query.pageSize
  };
}
async function taskSubjects(db, query) {
  const where = query.keyword ? " WHERE subject LIKE ? ESCAPE '!'" : "";
  const values = query.keyword ? [likeValue(query.keyword)] : [];
  const [counts] = await db.execute(
    "SELECT COUNT(DISTINCT subject) AS total FROM tasks" + where + " LIMIT 1",
    values
  );
  const [rows] = await db.execute(
    "SELECT DISTINCT subject AS value FROM tasks" + where + " ORDER BY value LIMIT ? OFFSET ?",
    [...values, query.pageSize, (query.page - 1) * query.pageSize]
  );
  return {
    items: rows.map((row) => ({ value: String(row.value) })),
    total: Number(counts[0].total),
    page: query.page,
    pageSize: query.pageSize
  };
}
async function findTask(db, id) {
  var _a;
  const [rows] = await db.execute(
    "SELECT " + fields + joins + " WHERE t.id=? LIMIT 1",
    [id]
  );
  if (!rows[0]) throw new ApiError(404, "NOT_FOUND", "\u672A\u627E\u5230\u4EFB\u52A1\u5B9A\u4E49\u3002");
  const counts = await taskAssignmentCounts(db, [id]);
  return { ...projectTask(rows[0]), assignmentCount: (_a = counts.get(id)) != null ? _a : 0 };
}
async function createTask(db, input, actor) {
  var _a;
  await requirePlan(db, input.studyPlanId);
  const result = await executeWrite(
    db,
    "INSERT INTO tasks (owner_user_id,study_plan_id,title,subject,description) VALUES (?,?,?,?,?)",
    [
      actor,
      (_a = input.studyPlanId) != null ? _a : null,
      input.title,
      input.subject,
      input.description
    ]
  );
  const task = await findTask(db, String(result.insertId));
  await writeAuditLog(db, {
    actorUserId: actor,
    action: "task.create",
    entityType: "task",
    entityId: task.id,
    after: auditSummary(task)
  });
  return task;
}
async function updateTask(db, input, actor) {
  const full = "title" in input;
  const before = await findTask(db, input.id);
  if (full) await requirePlan(db, input.studyPlanId);
  const sets = [];
  const values = [];
  if (full) {
    sets.push("title=?", "subject=?", "description=?");
    values.push(input.title, input.subject, input.description);
    if (input.studyPlanId !== void 0) {
      sets.push("study_plan_id=?");
      values.push(input.studyPlanId);
    }
  }
  sets.push(
    "status=?",
    "owner_user_id=?",
    "updated_at=UTC_TIMESTAMP(3)",
    "version=version+1"
  );
  values.push(input.status, actor, input.id, String(input.expectedVersion));
  const result = await executeWrite(
    db,
    "UPDATE tasks SET " + sets.join(",") + " WHERE id=? AND version=? AND version<4294967295",
    values
  );
  if (!result.affectedRows) {
    await findTask(db, input.id);
    throw new ApiError(
      409,
      "VERSION_CONFLICT",
      "\u4EFB\u52A1\u5DF2\u88AB\u4FEE\u6539\uFF1B\u7F16\u8F91\u5185\u5BB9\u5DF2\u4FDD\u7559\uFF0C\u8BF7\u6838\u5BF9\u6700\u65B0\u7248\u672C\u540E\u91CD\u8BD5\u3002"
    );
  }
  const task = await findTask(db, input.id);
  await writeAuditLog(db, {
    actorUserId: actor,
    action: full ? "task.update" : "task.status",
    entityType: "task",
    entityId: task.id,
    before: auditSummary(before),
    after: auditSummary(task)
  });
  return task;
}

export { createTask as c, findTask as f, listTasks as l, taskSubjects as t, updateTask as u };
//# sourceMappingURL=tasks.mjs.map
