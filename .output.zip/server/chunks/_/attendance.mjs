import { h as studentGrades, A as ApiError, j as dateOnly, k as uint, p as positiveId, l as shanghaiToday, m as executeWrite } from './nitro.mjs';
import { l as likeValue } from './contracts.mjs';
import { w as writeAuditLog } from './audit.mjs';

const attendanceStatuses = [
  "scheduled",
  "present",
  "sick_leave",
  "personal_leave",
  "absent"
];
const attendancePeriods = ["morning", "afternoon", "evening"];

function invalid(message) {
  throw new ApiError(400, "VALIDATION_ERROR", message);
}
function month(value) {
  if (typeof value !== "string" || !/^\d{4}-\d{2}$/u.test(value))
    invalid("\u6708\u4EFD\u683C\u5F0F\u65E0\u6548\u3002");
  const first = value + "-01";
  if (first < "1900-01-01") invalid("\u6708\u4EFD\u683C\u5F0F\u65E0\u6548\u3002");
  const date = /* @__PURE__ */ new Date(first + "T00:00:00Z");
  if (!Number.isFinite(date.getTime()) || date.toISOString().slice(0, 7) !== value)
    invalid("\u6708\u4EFD\u683C\u5F0F\u65E0\u6548\u3002");
  return value;
}
function text(value, max) {
  if (typeof value !== "string" || [...value].length > max)
    invalid("\u67E5\u8BE2\u53C2\u6570\u65E0\u6548\u3002");
  return value.trim();
}
function status(value) {
  if (!attendanceStatuses.includes(value))
    invalid("\u51FA\u52E4\u72B6\u6001\u65E0\u6548\u3002");
  return value;
}
function period(value) {
  if (!attendancePeriods.includes(value))
    invalid("\u51FA\u52E4\u65F6\u6BB5\u65E0\u6548\u3002");
  return value;
}
function parseAttendanceMonthQuery(input) {
  const allowed = ["month", "keyword", "grade", "gender", "status"];
  if (Object.keys(input).some((key) => !allowed.includes(key)))
    invalid("\u67E5\u8BE2\u53C2\u6570\u65E0\u6548\u3002");
  const grade = input.grade === void 0 ? void 0 : text(input.grade, 16);
  const gender = input.gender === void 0 ? void 0 : text(input.gender, 2);
  const studentStatus = input.status === void 0 ? void 0 : text(input.status, 16);
  if (grade !== void 0 && !studentGrades.includes(grade))
    invalid("\u5E74\u7EA7\u7B5B\u9009\u65E0\u6548\u3002");
  if (gender !== void 0 && gender !== "\u7537" && gender !== "\u5973")
    invalid("\u6027\u522B\u7B5B\u9009\u65E0\u6548\u3002");
  if (studentStatus !== void 0 && !["\u5728\u8BFB", "\u5F85\u5206\u914D", "\u5DF2\u7ED3\u8BFE"].includes(studentStatus))
    invalid("\u5B66\u751F\u72B6\u6001\u7B5B\u9009\u65E0\u6548\u3002");
  return {
    month: month(input.month),
    keyword: input.keyword === void 0 ? void 0 : text(input.keyword, 64),
    grade,
    gender,
    status: studentStatus
  };
}
function parseAttendanceSummaryQuery(input) {
  const allowed = ["month", "keyword", "grade", "gender", "status", "period"];
  if (Object.keys(input).some((key) => !allowed.includes(key)))
    invalid("\u67E5\u8BE2\u53C2\u6570\u65E0\u6548\u3002");
  const { period: selectedPeriod, ...query } = input;
  if (selectedPeriod !== "all" && !attendancePeriods.includes(selectedPeriod))
    invalid("\u51FA\u52E4\u65F6\u6BB5\u65E0\u6548\u3002");
  return {
    ...parseAttendanceMonthQuery(query),
    period: selectedPeriod
  };
}
function parseAttendanceCellWrite(body, today = shanghaiToday()) {
  if (!body || typeof body !== "object" || Array.isArray(body))
    invalid("\u51FA\u52E4\u8BF7\u6C42\u987B\u4E3AJSON\u5BF9\u8C61\u3002");
  const input = body;
  const allowed = [
    "studentId",
    "attendanceDate",
    "period",
    "status",
    "expectedVersion"
  ];
  if (Object.keys(input).some((key) => !allowed.includes(key)))
    invalid("\u8BF7\u6C42\u542B\u4E0D\u53EF\u5199\u5B57\u6BB5\u3002");
  const attendanceDate = dateOnly(input.attendanceDate);
  if (attendanceDate < "1900-01-01") invalid("\u51FA\u52E4\u65E5\u671F\u4E0D\u5F97\u65E9\u4E8E1900-01-01\u3002");
  const attendanceStatus = status(input.status);
  if (attendanceDate > today && attendanceStatus !== "scheduled")
    invalid("\u672A\u6765\u65E5\u671F\u53EA\u80FD\u6807\u8BB0\u6709\u8BFE\u3002");
  const expectedVersion = input.expectedVersion === null ? null : uint(input.expectedVersion, "\u7248\u672C\u53F7", true);
  return {
    studentId: positiveId(input.studentId),
    attendanceDate,
    period: period(input.period),
    status: attendanceStatus,
    expectedVersion
  };
}
function attendanceMonthRange(value) {
  const [yearText = "", monthText = ""] = value.split("-");
  const year = Number(yearText);
  const monthNumber = Number(monthText);
  const next = monthNumber === 12 ? `${String(year + 1).padStart(4, "0")}-01-01` : `${String(year).padStart(4, "0")}-${String(monthNumber + 1).padStart(2, "0")}-01`;
  return { start: value + "-01", end: next };
}

const maxAttendanceStudents = 200;
function toIso(value) {
  return value.replace(" ", "T") + "Z";
}
function projectAttendanceRecord(row) {
  return {
    id: String(row.id),
    studentId: String(row.student_id),
    attendanceDate: row.attendance_date,
    period: row.period,
    status: row.status,
    version: Number(row.version),
    createdAt: toIso(row.created_at),
    updatedAt: toIso(row.updated_at)
  };
}
function attendanceStudentFilter(query) {
  const clauses = [];
  const values = [];
  if (query.keyword) {
    clauses.push("s.name LIKE ? ESCAPE '!'");
    values.push(likeValue(query.keyword));
  }
  if (query.grade) {
    clauses.push("s.grade=?");
    values.push(query.grade);
  }
  if (query.gender) {
    clauses.push("s.gender=?");
    values.push(query.gender);
  }
  if (query.status) {
    clauses.push("s.status=?");
    values.push(query.status);
  }
  return {
    sql: clauses.length ? " WHERE " + clauses.join(" AND ") : "",
    values
  };
}
async function attendanceStudents(connection, query) {
  var _a, _b;
  const filter = attendanceStudentFilter(query);
  const [counts] = await connection.execute(
    "SELECT COUNT(*) AS total FROM students s" + filter.sql,
    filter.values
  );
  const total = Number((_b = (_a = counts[0]) == null ? void 0 : _a.total) != null ? _b : 0);
  if (total > maxAttendanceStudents)
    throw new ApiError(
      400,
      "VALIDATION_ERROR",
      "\u5F53\u524D\u7B5B\u9009\u5B66\u751F\u8D85\u8FC7200\u4EBA\uFF0C\u6682\u4E0D\u652F\u6301\u4E00\u6B21\u52A0\u8F7D\u6708\u5EA6\u77E9\u9635\u3002"
    );
  const [rows] = await connection.execute(
    "SELECT s.id,s.name,s.grade,s.gender,s.status FROM students s" + filter.sql + " ORDER BY s.name ASC,s.id ASC LIMIT ?",
    [...filter.values, maxAttendanceStudents]
  );
  return {
    total,
    students: rows.map((row) => ({
      id: String(row.id),
      name: row.name,
      grade: row.grade,
      gender: row.gender,
      status: row.status
    }))
  };
}
async function listAttendanceMonth(connection, query) {
  const { students, total } = await attendanceStudents(connection, query);
  if (!students.length)
    return { month: query.month, students, records: [], total };
  const { start, end } = attendanceMonthRange(query.month);
  const ids = students.map((student) => student.id);
  const [rows] = await connection.execute(
    "SELECT id,student_id,attendance_date,period,status,version,created_at,updated_at FROM attendance_records WHERE student_id IN (" + ids.map(() => "?").join(",") + ") AND attendance_date>=? AND attendance_date<? ORDER BY attendance_date,id LIMIT ?",
    [...ids, start, end, maxAttendanceStudents * 31 * 3]
  );
  return {
    month: query.month,
    students,
    records: rows.map(projectAttendanceRecord),
    total
  };
}
async function attendanceTodaySummary(connection, query, selectedPeriod, today = shanghaiToday()) {
  const counts = Object.fromEntries(
    attendanceStatuses.map((status) => [status, 0])
  );
  if (query.month !== today.slice(0, 7)) return { date: null, counts };
  const filter = attendanceStudentFilter(query);
  const clauses = ["r.attendance_date=?"];
  const values = [today];
  if (selectedPeriod !== "all") {
    clauses.push("r.period=?");
    values.push(selectedPeriod);
  }
  const where = " WHERE " + clauses.join(" AND ") + (filter.sql ? " AND " + filter.sql.slice(" WHERE ".length) : "");
  const [rows] = await connection.execute(
    "SELECT r.status,COUNT(*) AS total FROM attendance_records r JOIN students s ON s.id=r.student_id" + where + " GROUP BY r.status LIMIT 5",
    [...values, ...filter.values]
  );
  for (const row of rows) counts[row.status] = Number(row.total);
  return { date: today, counts };
}
async function requireAttendanceStudent(connection, studentId) {
  const [rows] = await connection.execute(
    "SELECT id FROM students WHERE id=? LIMIT 1",
    [studentId]
  );
  if (!rows.length) throw new ApiError(404, "NOT_FOUND", "\u672A\u627E\u5230\u6240\u9009\u5B66\u751F\u3002");
}
async function findAttendanceRecord(connection, input, locked = false) {
  const [rows] = await connection.execute(
    "SELECT id,student_id,attendance_date,period,status,version,created_at,updated_at FROM attendance_records WHERE student_id=? AND attendance_date=? AND period=? LIMIT 1" + (locked ? " FOR UPDATE" : ""),
    [input.studentId, input.attendanceDate, input.period]
  );
  if (!rows[0]) throw new ApiError(404, "NOT_FOUND", "\u672A\u627E\u5230\u51FA\u52E4\u8BB0\u5F55\u3002");
  return projectAttendanceRecord(rows[0]);
}
function summary(record) {
  return {
    attendanceDate: record.attendanceDate,
    period: record.period,
    status: record.status
  };
}
function conflict() {
  throw new ApiError(
    409,
    "VERSION_CONFLICT",
    "\u8BE5\u65F6\u6BB5\u8BB0\u5F55\u5DF2\u88AB\u5176\u4ED6\u7A97\u53E3\u66F4\u65B0\uFF0C\u8BF7\u4FDD\u7559\u9009\u62E9\u5E76\u5237\u65B0\u5F53\u6708\u6570\u636E\u540E\u6838\u5BF9\u3002"
  );
}
function duplicate(error) {
  return typeof error === "object" && error !== null && "code" in error && error.code === "ER_DUP_ENTRY";
}
async function setAttendanceCell(connection, input, actorId) {
  await requireAttendanceStudent(connection, input.studentId);
  if (input.expectedVersion === null) {
    try {
      const result2 = await executeWrite(
        connection,
        "INSERT INTO attendance_records (student_id,attendance_date,period,status,created_by,updated_by) VALUES (?,?,?,?,?,?)",
        [
          input.studentId,
          input.attendanceDate,
          input.period,
          input.status,
          actorId,
          actorId
        ]
      );
      const created = await findAttendanceRecord(connection, input);
      if (created.id !== String(result2.insertId))
        throw new Error("\u51FA\u52E4\u8BB0\u5F55\u56DE\u8BFB\u4E0D\u4E00\u81F4\u3002");
      await writeAuditLog(connection, {
        actorUserId: actorId,
        action: "attendance_record.create",
        entityType: "attendance_record",
        entityId: created.id,
        studentId: created.studentId,
        after: summary(created)
      });
      return created;
    } catch (error) {
      if (duplicate(error)) conflict();
      throw error;
    }
  }
  let before;
  try {
    before = await findAttendanceRecord(connection, input);
  } catch (error) {
    if (error instanceof ApiError && error.statusCode === 404) conflict();
    throw error;
  }
  if (before.version !== input.expectedVersion || before.version >= 4294967295)
    conflict();
  const result = await executeWrite(
    connection,
    "UPDATE attendance_records SET status=?,updated_by=?,version=version+1,updated_at=UTC_TIMESTAMP(3) WHERE student_id=? AND attendance_date=? AND period=? AND version=? AND version<4294967295 AND status<>?",
    [
      input.status,
      actorId,
      input.studentId,
      input.attendanceDate,
      input.period,
      input.expectedVersion,
      input.status
    ]
  );
  if (!result.affectedRows) {
    let current;
    try {
      current = await findAttendanceRecord(connection, input, true);
    } catch (error) {
      if (error instanceof ApiError && error.statusCode === 404) conflict();
      throw error;
    }
    if (current.version === input.expectedVersion && current.status === input.status)
      return current;
    conflict();
  }
  const updated = await findAttendanceRecord(connection, input, true);
  await writeAuditLog(connection, {
    actorUserId: actorId,
    action: "attendance_record.update",
    entityType: "attendance_record",
    entityId: updated.id,
    studentId: updated.studentId,
    before: summary(before),
    after: summary(updated)
  });
  return updated;
}

export { parseAttendanceCellWrite as a, parseAttendanceSummaryQuery as b, attendanceTodaySummary as c, listAttendanceMonth as l, parseAttendanceMonthQuery as p, setAttendanceCell as s };
//# sourceMappingURL=attendance.mjs.map
