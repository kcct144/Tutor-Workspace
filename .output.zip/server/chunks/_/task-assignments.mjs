import { L as parseStudentQuery, A as ApiError, l as shanghaiToday, k as uint, p as positiveId, j as dateOnly, m as executeWrite } from './nitro.mjs';
import { w as writeAuditLog } from './audit.mjs';
import { l as likeValue } from './contracts.mjs';

function invalid(message = "\u4EFB\u52A1\u5206\u914D\u53C2\u6570\u65E0\u6548\u3002") {
  throw new ApiError(400, "VALIDATION_ERROR", message);
}
function fields(value, allowed) {
  if (!value || typeof value !== "object" || Array.isArray(value)) invalid();
  const input = value;
  if (Object.keys(input).some((key) => !allowed.includes(key)))
    invalid("\u8BF7\u6C42\u542B\u672A\u77E5\u5B57\u6BB5\uFF1B\u64CD\u4F5C\u4EBA\u53CA\u65E5\u671F\u57FA\u51C6\u53EA\u80FD\u6765\u81EA\u670D\u52A1\u7AEF\u3002");
  return input;
}
function parseAssignmentQuery(value) {
  const input = fields(value, [
    "page",
    "pageSize",
    "keyword",
    "studentId",
    "taskId",
    "subject",
    "status",
    "dueState"
  ]);
  const page = parseStudentQuery({
    page: input.page,
    pageSize: input.pageSize,
    keyword: input.keyword
  });
  if (input.status !== void 0 && !["pending", "completed"].includes(String(input.status)))
    invalid();
  if (input.status !== void 0 && typeof input.status !== "string") invalid();
  if (input.dueState !== void 0 && (typeof input.dueState !== "string" || !["overdue", "today", "upcoming"].includes(input.dueState)))
    invalid();
  if (input.subject !== void 0 && (typeof input.subject !== "string" || !input.subject.trim() || [...input.subject].length > 64))
    invalid();
  return {
    page: page.page,
    pageSize: page.pageSize,
    keyword: page.keyword,
    studentId: input.studentId === void 0 ? void 0 : positiveId(input.studentId),
    taskId: input.taskId === void 0 ? void 0 : positiveId(input.taskId),
    subject: typeof input.subject === "string" ? input.subject.trim() : void 0,
    status: input.status,
    dueState: input.dueState
  };
}
function parseAssignmentBatch(value, today = shanghaiToday()) {
  const input = fields(value, ["taskId", "studentIds", "dueDate"]);
  if (!Array.isArray(input.studentIds) || input.studentIds.length < 1 || input.studentIds.length > 100)
    invalid("\u6BCF\u6B21\u987B\u9009\u62E91\u2013100\u540D\u5B66\u751F\u3002");
  const studentIds = input.studentIds.map(positiveId);
  if (new Set(studentIds).size !== studentIds.length)
    invalid("\u5B66\u751F\u4E0D\u53EF\u91CD\u590D\u9009\u62E9\u3002");
  const dueDate = dateOnly(input.dueDate);
  if (dueDate < today) invalid("\u622A\u6B62\u65E5\u671F\u4E0D\u5F97\u65E9\u4E8E\u4ECA\u5929\u3002");
  return { taskId: positiveId(input.taskId), studentIds, dueDate };
}
function parseAssignmentCompletion(value) {
  const input = fields(value, ["id", "completed", "expectedVersion"]);
  if (typeof input.completed !== "boolean") invalid("\u5B8C\u6210\u72B6\u6001\u987B\u4E3A\u5E03\u5C14\u503C\u3002");
  return {
    id: positiveId(input.id),
    completed: input.completed,
    expectedVersion: uint(input.expectedVersion, "\u7248\u672C\u53F7", true)
  };
}
function assignmentDueState(status, date, today = shanghaiToday()) {
  return status === "completed" ? null : date < today ? "overdue" : date === today ? "today" : "upcoming";
}
function parseHomeQuery(value) {
  var _a;
  const input = fields(value, ["page", "pageSize", "grade"]);
  const query = parseStudentQuery({
    page: input.page,
    pageSize: (_a = input.pageSize) != null ? _a : "20",
    grade: input.grade
  });
  return { page: query.page, pageSize: query.pageSize, grade: query.grade };
}

const columns = "a.id,a.task_id,a.student_id,a.study_plan_id_snapshot,t.title AS task_title,t.description,t.subject,s.name AS student_name,p.title AS study_plan_title,a.status,a.assigned_at,a.due_date,a.completed_at,a.created_at,a.updated_at,a.version";
const joins = " FROM task_assignments a JOIN tasks t ON t.id=a.task_id JOIN students s ON s.id=a.student_id LEFT JOIN study_plan_documents p ON p.id=a.study_plan_id_snapshot";
const time = (value) => value.replace(" ", "T") + "Z";
function projectAssignment(row, today) {
  var _a;
  return {
    id: String(row.id),
    taskId: String(row.task_id),
    studentId: String(row.student_id),
    taskTitle: row.task_title,
    description: row.description,
    subject: row.subject,
    studentName: row.student_name,
    status: row.status,
    assignedAt: time(row.assigned_at),
    dueDate: row.due_date,
    completedAt: row.completed_at ? time(row.completed_at) : null,
    createdAt: time(row.created_at),
    updatedAt: time(row.updated_at),
    version: row.version,
    planSnapshot: row.study_plan_id_snapshot ? {
      id: String(row.study_plan_id_snapshot),
      title: (_a = row.study_plan_title) != null ? _a : ""
    } : null,
    dueState: assignmentDueState(row.status, row.due_date, today)
  };
}
const assignmentOrder = "a.status='pending' DESC,CASE WHEN a.status='pending' THEN a.due_date END ASC,CASE WHEN a.status='pending' THEN a.id END ASC,CASE WHEN a.status='completed' THEN a.completed_at END DESC,a.id DESC";
async function findAssignment(db, id, today = shanghaiToday(), locking = false) {
  const [rows] = await db.execute(
    "SELECT " + columns + joins + " WHERE a.id=? LIMIT 1" + (locking ? " FOR UPDATE OF a" : ""),
    [id]
  );
  if (!rows[0]) throw new ApiError(404, "NOT_FOUND", "\u672A\u627E\u5230\u4EFB\u52A1\u5206\u914D\u3002");
  return projectAssignment(rows[0], today);
}
function filter(query, today) {
  const clauses = [], values = [];
  if (query.keyword) {
    clauses.push("(t.title LIKE ? ESCAPE '!' OR s.name LIKE ? ESCAPE '!')");
    values.push(likeValue(query.keyword), likeValue(query.keyword));
  }
  for (const [key, column] of [
    ["taskId", "a.task_id"],
    ["studentId", "a.student_id"],
    ["subject", "t.subject"],
    ["status", "a.status"]
  ]) {
    if (query[key]) {
      clauses.push(column + "=?");
      values.push(query[key]);
    }
  }
  if (query.dueState) {
    clauses.push(
      "a.status='pending'",
      "a.due_date" + { overdue: "<", today: "=", upcoming: ">" }[query.dueState] + "?"
    );
    values.push(today);
  }
  return {
    sql: clauses.length ? " WHERE " + clauses.join(" AND ") : "",
    values
  };
}
async function listAssignments(db, query, today = shanghaiToday()) {
  for (const [id, table] of [
    [query.studentId, "students"],
    [query.taskId, "tasks"]
  ]) {
    if (id) {
      const [rows2] = await db.execute(
        "SELECT id FROM " + table + " WHERE id=? LIMIT 1",
        [id]
      );
      if (!rows2.length)
        throw new ApiError(404, "NOT_FOUND", "\u672A\u627E\u5230\u7B5B\u9009\u7684\u5B66\u751F\u6216\u4EFB\u52A1\u3002");
    }
  }
  const where = filter(query, today);
  const [counts] = await db.execute(
    "SELECT COUNT(*) AS total" + joins + where.sql + " LIMIT 1",
    where.values
  );
  const [rows] = await db.execute(
    "SELECT " + columns + joins + where.sql + " ORDER BY " + assignmentOrder + " LIMIT ? OFFSET ?",
    [...where.values, query.pageSize, (query.page - 1) * query.pageSize]
  );
  return {
    items: rows.map((row) => projectAssignment(row, today)),
    total: Number(counts[0].total),
    page: query.page,
    pageSize: query.pageSize
  };
}
function conflict(message) {
  throw new ApiError(409, "ASSIGNMENT_CONFLICT", message);
}
function planNotLinked() {
  throw new ApiError(
    409,
    "STUDENT_PLAN_NOT_LINKED",
    "\u6240\u9009\u5B66\u751F\u672A\u5173\u8054\u8BE5\u5B66\u4E60\u8BA1\u5212\uFF0C\u8BF7\u8C03\u6574\u5B66\u751F\u6216\u5148\u5EFA\u7ACB\u8BA1\u5212\u5173\u8054\u3002"
  );
}
function duplicate(error) {
  return !!error && typeof error === "object" && "code" in error && error.code === "ER_DUP_ENTRY";
}
async function createAssignmentBatch(db, input, actor) {
  var _a;
  const [tasks] = await db.execute(
    "SELECT t.id,t.status,t.study_plan_id,p.title AS study_plan_title FROM tasks t LEFT JOIN study_plan_documents p ON p.id=t.study_plan_id WHERE t.id=? LIMIT 1 FOR UPDATE",
    [input.taskId]
  );
  if (!tasks[0]) throw new ApiError(404, "NOT_FOUND", "\u672A\u627E\u5230\u4EFB\u52A1\u5B9A\u4E49\u3002");
  if (tasks[0].status !== "enabled") conflict("\u505C\u7528\u4EFB\u52A1\u4E0D\u80FD\u521B\u5EFA\u5206\u914D\u3002");
  const slots = input.studentIds.map(() => "?").join(",");
  const [students] = await db.execute(
    "SELECT id FROM students WHERE id IN (" + slots + ") ORDER BY id LIMIT ? FOR SHARE",
    [...input.studentIds, input.studentIds.length]
  );
  if (students.length !== input.studentIds.length)
    throw new ApiError(404, "NOT_FOUND", "\u5B58\u5728\u672A\u627E\u5230\u7684\u5B66\u751F\uFF0C\u6574\u6279\u672A\u521B\u5EFA\u3002");
  const studyPlanId = tasks[0].study_plan_id;
  if (studyPlanId) {
    const [linked] = await db.execute(
      "SELECT student_id FROM study_plan_students WHERE plan_id=? AND student_id IN (" + slots + ") ORDER BY student_id LIMIT ? FOR SHARE",
      [studyPlanId, ...input.studentIds, input.studentIds.length]
    );
    if (linked.length !== input.studentIds.length) planNotLinked();
  }
  const [pending] = await db.execute(
    "SELECT id FROM task_assignments WHERE task_id=? AND student_id IN (" + slots + ") AND pending_marker=1 LIMIT ? FOR UPDATE",
    [input.taskId, ...input.studentIds, input.studentIds.length]
  );
  if (pending.length)
    conflict("\u6240\u9009\u5B66\u751F\u5B58\u5728\u540C\u4E00\u4EFB\u52A1\u7684\u5F85\u5B8C\u6210\u5206\u914D\uFF0C\u6574\u6279\u672A\u521B\u5EFA\u3002");
  try {
    await executeWrite(
      db,
      "INSERT INTO task_assignments (task_id,student_id,study_plan_id_snapshot,assigned_by,due_date) VALUES " + input.studentIds.map(() => "(?,?,?,?,?)").join(","),
      input.studentIds.flatMap((id) => [
        input.taskId,
        id,
        studyPlanId,
        actor,
        input.dueDate
      ])
    );
  } catch (error) {
    if (duplicate(error)) conflict("\u5F85\u5B8C\u6210\u5206\u914D\u51B2\u7A81\uFF0C\u6574\u6279\u672A\u521B\u5EFA\u3002");
    throw error;
  }
  const [created] = await db.execute(
    "SELECT id FROM task_assignments WHERE task_id=? AND student_id IN (" + slots + ") AND pending_marker=1 ORDER BY id LIMIT ? FOR UPDATE",
    [input.taskId, ...input.studentIds, input.studentIds.length]
  );
  if (created.length !== input.studentIds.length)
    throw new Error("\u4EFB\u52A1\u5206\u914D\u56DE\u8BFB\u4E0D\u5B8C\u6574\u3002");
  const [auditRows] = await db.execute(
    "SELECT id,student_id,status,due_date,study_plan_id_snapshot FROM task_assignments WHERE id IN (" + created.map(() => "?").join(",") + ") ORDER BY id LIMIT ?",
    [...created.map((row) => String(row.id)), created.length]
  );
  for (const row of auditRows) {
    await writeAuditLog(db, {
      actorUserId: actor,
      action: "task_assignment.create",
      entityType: "task_assignment",
      entityId: String(row.id),
      studentId: String(row.student_id),
      after: {
        taskId: input.taskId,
        dueDate: String(row.due_date),
        status: String(row.status),
        studyPlanId: row.study_plan_id_snapshot ? String(row.study_plan_id_snapshot) : null
      }
    });
  }
  return {
    assignmentIds: created.map((row) => String(row.id)),
    createdCount: created.length,
    planSnapshot: studyPlanId ? { id: studyPlanId, title: String((_a = tasks[0].study_plan_title) != null ? _a : "") } : null
  };
}
async function completeAssignment(db, input, actor, today = shanghaiToday()) {
  const status = input.completed ? "completed" : "pending";
  let changed;
  try {
    const result = await executeWrite(
      db,
      "UPDATE task_assignments SET status=?,completed_at=" + (input.completed ? "UTC_TIMESTAMP(3)" : "NULL") + ",updated_at=UTC_TIMESTAMP(3),version=version+1 WHERE id=? AND version=? AND status<>? AND version<4294967295",
      [status, input.id, input.expectedVersion, status]
    );
    changed = result.affectedRows === 1;
  } catch (error) {
    if (duplicate(error))
      conflict("\u5DF2\u6709\u540C\u4E00\u5B66\u751F\u548C\u4EFB\u52A1\u7684\u5F85\u5B8C\u6210\u5206\u914D\uFF0C\u65E0\u6CD5\u6062\u590D\uFF1B\u539F\u5B8C\u6210\u72B6\u6001\u4FDD\u7559\u3002");
    throw error;
  }
  const current = await findAssignment(db, input.id, today, true);
  if (current.version === input.expectedVersion && current.status === status)
    return current;
  if (changed && current.version === input.expectedVersion + 1 && current.status === status) {
    await writeAuditLog(db, {
      actorUserId: actor,
      action: "task_assignment.completion",
      entityType: "task_assignment",
      entityId: current.id,
      studentId: current.studentId,
      before: { status: input.completed ? "pending" : "completed" },
      after: { status: current.status }
    });
    return current;
  }
  conflict("\u4EFB\u52A1\u5206\u914D\u7248\u672C\u5DF2\u53D8\u5316\uFF0C\u8BF7\u5237\u65B0\u540E\u91CD\u8BD5\u3002");
}
async function taskAssignmentCounts(db, ids) {
  const counts = /* @__PURE__ */ new Map();
  if (!ids.length) return counts;
  const [rows] = await db.execute(
    "SELECT task_id,COUNT(DISTINCT student_id) AS count FROM task_assignments WHERE task_id IN (" + ids.map(() => "?").join(",") + ") GROUP BY task_id LIMIT ?",
    [...ids, ids.length]
  );
  for (const row of rows) counts.set(String(row.task_id), Number(row.count));
  return counts;
}
async function studentAssignmentSummaries(db, ids, today) {
  var _a;
  const result = /* @__PURE__ */ new Map();
  if (!ids.length) return result;
  const ranked = "SELECT " + columns + ",COUNT(*) OVER (PARTITION BY a.student_id,a.status) AS group_count,ROW_NUMBER() OVER (PARTITION BY a.student_id,a.status ORDER BY " + assignmentOrder + ") AS row_number_in_group" + joins + " WHERE a.student_id IN (" + ids.map(() => "?").join(",") + ")";
  const [rows] = await db.execute(
    "SELECT id,task_id,student_id,task_title,description,subject,student_name,status,assigned_at,due_date,completed_at,created_at,updated_at,version,group_count FROM (" + ranked + ") ranked WHERE row_number_in_group<=3 ORDER BY student_id,status,row_number_in_group LIMIT ?",
    [...ids, ids.length * 6]
  );
  for (const row of rows) {
    const id = String(row.student_id), group = (_a = result.get(id)) != null ? _a : {
      pendingTasks: [],
      completedTasks: [],
      pendingCount: 0,
      completedCount: 0
    };
    if (row.status === "pending") {
      group.pendingTasks.push(projectAssignment(row, today));
      group.pendingCount = Number(row.group_count);
    } else {
      group.completedTasks.push(projectAssignment(row, today));
      group.completedCount = Number(row.group_count);
    }
    result.set(id, group);
  }
  return result;
}

export { parseAssignmentCompletion as a, parseAssignmentBatch as b, completeAssignment as c, createAssignmentBatch as d, parseAssignmentQuery as e, listAssignments as l, parseHomeQuery as p, studentAssignmentSummaries as s, taskAssignmentCounts as t };
//# sourceMappingURL=task-assignments.mjs.map
