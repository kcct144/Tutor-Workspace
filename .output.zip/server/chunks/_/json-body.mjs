import { g as getQuery, A as ApiError, P as getHeader } from './nitro.mjs';

async function jsonBody(event, limit) {
  var _a;
  if (Object.keys(getQuery(event)).length)
    throw new ApiError(400, "VALIDATION_ERROR", "\u5199\u8BF7\u6C42\u4E0D\u63A5\u53D7\u67E5\u8BE2\u53C2\u6570\u3002");
  if (!((_a = getHeader(event, "content-type")) == null ? void 0 : _a.toLowerCase().startsWith("application/json")))
    throw new ApiError(400, "VALIDATION_ERROR", "\u8BF7\u53D1\u9001JSON\u8BF7\u6C42\u3002");
  const raw = await new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0;
    event.node.req.on("data", (chunk) => {
      size += chunk.length;
      if (size <= limit) chunks.push(chunk);
      else chunks.length = 0;
    });
    event.node.req.on(
      "end",
      () => size > limit ? reject(
        new ApiError(413, "PAYLOAD_TOO_LARGE", "\u8BF7\u6C42\u6B63\u6587\u8D85\u8FC7\u5927\u5C0F\u9650\u5236\u3002")
      ) : resolve(Buffer.concat(chunks))
    );
    event.node.req.on(
      "error",
      () => reject(new ApiError(400, "VALIDATION_ERROR", "\u8BF7\u6C42\u8BFB\u53D6\u5931\u8D25\u3002"))
    );
    event.node.req.on(
      "aborted",
      () => reject(new ApiError(400, "VALIDATION_ERROR", "\u8BF7\u6C42\u5DF2\u4E2D\u65AD\u3002"))
    );
  });
  try {
    return JSON.parse(raw.toString("utf8"));
  } catch {
    throw new ApiError(400, "VALIDATION_ERROR", "JSON\u683C\u5F0F\u65E0\u6548\u3002");
  }
}

export { jsonBody as j };
//# sourceMappingURL=json-body.mjs.map
