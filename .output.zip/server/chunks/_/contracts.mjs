import { randomUUID } from 'node:crypto';
import { m as executeWrite, A as ApiError, l as shanghaiToday, O as contractStatusSql } from './nitro.mjs';

function project(row) {
  return {
    id: String(row.id),
    contractNo: row.contract_no,
    studentId: String(row.student_id),
    studentName: row.student_name,
    subject: row.subject,
    contractType: row.contract_type,
    trialStatus: row.trial_status,
    startDate: row.start_date,
    endDate: row.end_date,
    attendedLessons: row.attended_lessons,
    totalLessons: row.total_lessons,
    makeupLessons: row.makeup_lessons,
    status: row.status,
    version: row.version,
    updatedAt: row.updated_at.replace(" ", "T") + "Z"
  };
}
const columns = "c.id, c.contract_no, c.student_id, s.name AS student_name, c.subject, c.contract_type, c.trial_status, c.start_date, c.end_date, c.attended_lessons, c.total_lessons, c.makeup_lessons, c.version, c.updated_at, (" + contractStatusSql + ") AS status";
function likeValue(value) {
  return "%" + value.replace(/[!%_]/g, (c) => "!" + c) + "%";
}
function contractFilter(query, today) {
  const clauses = [], values = [];
  if (query.keyword) {
    clauses.push(
      "(CONVERT(c.contract_no USING utf8mb4) LIKE ? ESCAPE '!' OR s.name LIKE ? ESCAPE '!' OR c.subject LIKE ? ESCAPE '!')"
    );
    values.push(...Array(3).fill(likeValue(query.keyword)));
  }
  for (const [key, column] of [
    ["studentId", "c.student_id"],
    ["subject", "c.subject"],
    ["contractType", "c.contract_type"]
  ]) {
    if (query[key]) {
      clauses.push(column + " = ?");
      values.push(query[key]);
    }
  }
  if (query.status) {
    clauses.push("(" + contractStatusSql + ") = ?");
    values.push(today, today, query.status);
  }
  return {
    sql: clauses.length ? " WHERE " + clauses.join(" AND ") : "",
    values
  };
}
async function listContracts(connection, query, today = shanghaiToday()) {
  const filter = contractFilter(query, today);
  const from = " FROM contracts c JOIN students s ON s.id = c.student_id" + filter.sql;
  const [counts] = await connection.execute(
    "SELECT COUNT(*) AS total" + from,
    filter.values
  );
  const [rows] = await connection.execute(
    "SELECT " + columns + from + " ORDER BY c.id DESC LIMIT ? OFFSET ?",
    [
      today,
      today,
      ...filter.values,
      query.pageSize,
      (query.page - 1) * query.pageSize
    ]
  );
  return {
    items: rows.map(project),
    total: Number(counts[0].total),
    page: query.page,
    pageSize: query.pageSize
  };
}
async function findContract(connection, id, today = shanghaiToday()) {
  const [rows] = await connection.execute(
    "SELECT " + columns + " FROM contracts c JOIN students s ON s.id = c.student_id WHERE c.id = ? LIMIT 1",
    [today, today, id]
  );
  if (!rows[0]) throw new ApiError(404, "NOT_FOUND", "\u672A\u627E\u5230\u5408\u540C\u3002");
  return project(rows[0]);
}
async function contractSubjects(connection, query) {
  const where = query.keyword ? " WHERE subject LIKE ? ESCAPE '!'" : "";
  const values = query.keyword ? [likeValue(query.keyword)] : [];
  const [counts] = await connection.execute(
    "SELECT COUNT(DISTINCT subject) AS total FROM contracts" + where,
    values
  );
  const [rows] = await connection.execute(
    "SELECT DISTINCT subject FROM contracts" + where + " ORDER BY subject LIMIT ? OFFSET ?",
    [...values, query.pageSize, (query.page - 1) * query.pageSize]
  );
  return {
    items: rows.map((row) => ({ value: String(row.subject) })),
    total: Number(counts[0].total),
    page: query.page,
    pageSize: query.pageSize
  };
}
async function requireStudent(connection, studentId) {
  const [rows] = await connection.execute(
    "SELECT id FROM students WHERE id = ? LIMIT 1",
    [studentId]
  );
  if (!rows.length)
    throw new ApiError(404, "STUDENT_NOT_FOUND", "\u6240\u9009\u5B66\u751F\u4E0D\u5B58\u5728\u3002");
}
function fields(input) {
  return [
    input.studentId,
    input.subject,
    input.contractType,
    input.startDate,
    input.endDate,
    input.attendedLessons,
    input.totalLessons,
    input.makeupLessons
  ];
}
async function createContract(connection, input, actorId) {
  await requireStudent(connection, input.studentId);
  for (let attempt = 0; attempt < 3; attempt++) {
    try {
      const result = await executeWrite(
        connection,
        "INSERT INTO contracts (contract_no, student_id, subject, contract_type, trial_status, start_date, end_date, attended_lessons, total_lessons, makeup_lessons, created_by, updated_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
        [
          randomUUID(),
          input.studentId,
          input.subject,
          input.contractType,
          input.contractType === "trial" ? "active" : null,
          input.startDate,
          input.endDate,
          input.attendedLessons,
          input.totalLessons,
          input.makeupLessons,
          actorId,
          actorId
        ]
      );
      return await findContract(connection, String(result.insertId));
    } catch (error) {
      if (!(error && typeof error === "object" && "code" in error && error.code === "ER_DUP_ENTRY"))
        throw error;
    }
  }
  throw new ApiError(
    409,
    "CONTRACT_NUMBER_CONFLICT",
    "\u5408\u540C\u7F16\u53F7\u751F\u6210\u51B2\u7A81\uFF0C\u8BF7\u7A0D\u540E\u91CD\u65B0\u64CD\u4F5C\u3002"
  );
}
async function updateContract(connection, input, actorId) {
  await requireStudent(connection, input.studentId);
  const current = await findContract(connection, input.id);
  if (current.contractType === "trial" !== (input.contractType === "trial"))
    throw new ApiError(400, "VALIDATION_ERROR", "\u4F53\u9A8C\u5408\u540C\u4E0D\u80FD\u5207\u6362\u4E3A\u5176\u4ED6\u7C7B\u578B\u3002");
  const result = await executeWrite(
    connection,
    "UPDATE contracts SET student_id = ?, subject = ?, contract_type = ?, start_date = ?, end_date = ?, attended_lessons = ?, total_lessons = ?, makeup_lessons = ?, updated_by = ?, updated_at = UTC_TIMESTAMP(3), version = version + 1 WHERE id = ? AND version = ? AND version < 4294967295",
    [...fields(input), actorId, input.id, input.expectedVersion]
  );
  if (!result.affectedRows) {
    await findContract(connection, input.id);
    throw new ApiError(
      409,
      "VERSION_CONFLICT",
      "\u5408\u540C\u5DF2\u88AB\u4FEE\u6539\uFF0C\u8BF7\u4FDD\u7559\u8F93\u5165\u5E76\u91CD\u65B0\u8F7D\u5165\u6700\u65B0\u7248\u672C\u3002"
    );
  }
  return findContract(connection, input.id);
}
async function terminateTrialContract(connection, id, expectedVersion, actorId) {
  const current = await findContract(connection, id);
  if (current.contractType !== "trial")
    throw new ApiError(400, "VALIDATION_ERROR", "\u4EC5\u4F53\u9A8C\u5408\u540C\u53EF\u4EE5\u7EC8\u6B62\u3002");
  if (current.version !== expectedVersion)
    throw new ApiError(409, "VERSION_CONFLICT", "\u5408\u540C\u5DF2\u88AB\u4FEE\u6539\uFF0C\u8BF7\u91CD\u65B0\u8F7D\u5165\u3002");
  if (current.trialStatus === "terminated") return current;
  const result = await executeWrite(
    connection,
    "UPDATE contracts SET trial_status='terminated',updated_by=?,updated_at=UTC_TIMESTAMP(3),version=version+1 WHERE id=? AND version=? AND trial_status='active' AND version < 4294967295",
    [actorId, id, expectedVersion]
  );
  if (!result.affectedRows)
    throw new ApiError(409, "VERSION_CONFLICT", "\u5408\u540C\u5DF2\u88AB\u4FEE\u6539\uFF0C\u8BF7\u91CD\u65B0\u8F7D\u5165\u3002");
  return findContract(connection, id);
}
async function studentContractAggregates(connection, ids, today = shanghaiToday()) {
  var _a;
  const result = /* @__PURE__ */ new Map();
  if (!ids.length) return result;
  const slots = ids.map(() => "?").join(",");
  const [rows] = await connection.execute(
    "SELECT a.student_id, JSON_ARRAYAGG(a.subject) AS subjects, MIN(a.expiry_date) AS expiry_date FROM (SELECT c.student_id, c.subject, MIN(CASE WHEN c.contract_type <> 'lessons' THEN c.end_date END) AS expiry_date FROM contracts c WHERE c.student_id IN (" + slots + ") AND ((" + contractStatusSql + ") = '\u751F\u6548\u4E2D' OR (" + contractStatusSql + ") = '\u8FDB\u884C\u4E2D') GROUP BY c.student_id, c.subject) a GROUP BY a.student_id LIMIT ?",
    [...ids, today, today, today, today, ids.length]
  );
  for (const row of rows) {
    const subjects = typeof row.subjects === "string" ? JSON.parse(row.subjects) : row.subjects;
    result.set(String(row.student_id), {
      subjects: subjects.sort(),
      expiryDate: (_a = row.expiry_date) != null ? _a : null
    });
  }
  return result;
}

export { listContracts as a, contractSubjects as b, createContract as c, findContract as f, likeValue as l, studentContractAggregates as s, terminateTrialContract as t, updateContract as u };
//# sourceMappingURL=contracts.mjs.map
