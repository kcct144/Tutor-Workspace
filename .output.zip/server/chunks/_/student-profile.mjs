import { S as StudentDuplicateError, m as executeWrite, A as ApiError } from './nitro.mjs';
import { f as findStudent } from './students.mjs';

async function findStudentEdit(db, id) {
  const [rows] = await db.execute(
    "SELECT id,name,grade,school,class_name,gender,enrolled_at,guardian_name,guardian_phone,note,version FROM students WHERE id=? LIMIT 1",
    [id]
  );
  const row = rows[0];
  if (!row) throw new ApiError(404, "NOT_FOUND", "\u672A\u627E\u5230\u5B66\u751F\u3002");
  return {
    id: String(row.id),
    name: row.name,
    grade: row.grade,
    school: row.school,
    className: row.class_name,
    gender: row.gender,
    enrolledAt: row.enrolled_at,
    guardianName: row.guardian_name,
    guardianPhone: row.guardian_phone,
    note: row.note,
    version: row.version
  };
}
function values(input) {
  return [
    input.name,
    input.grade,
    input.school,
    input.className,
    input.gender,
    input.enrolledAt,
    input.guardianName,
    input.guardianPhone,
    input.note
  ];
}
async function createStudent(db, input) {
  if (input.school && input.className) {
    const [rows] = await db.execute(
      "SELECT id,name,school,class_name,status FROM students WHERE BINARY name=BINARY ? AND BINARY school=BINARY ? AND BINARY class_name=BINARY ? ORDER BY id LIMIT 5",
      [input.name, input.school, input.className]
    );
    if (rows.length && !input.confirmPossibleDuplicate)
      throw new StudentDuplicateError(
        rows.map(
          (row) => ({
            id: String(row.id),
            name: row.name,
            school: row.school,
            className: row.class_name,
            status: row.status
          })
        )
      );
  }
  const result = await executeWrite(
    db,
    "INSERT INTO students (name,grade,school,class_name,gender,enrolled_at,guardian_name,guardian_phone,note,status,owner_user_id,version) VALUES (?,?,?,?,?,?,?,?,?,'\u5F85\u5206\u914D',NULL,1)",
    values(input)
  );
  return findStudent(db, String(result.insertId));
}
async function updateStudent(db, input) {
  const [rows] = await db.execute(
    "SELECT id,status,version FROM students WHERE id=? LIMIT 1 FOR UPDATE",
    [input.id]
  );
  const row = rows[0];
  if (!row) throw new ApiError(404, "NOT_FOUND", "\u672A\u627E\u5230\u5B66\u751F\u3002");
  const conflict = () => new ApiError(
    409,
    "VERSION_CONFLICT",
    "\u6863\u6848\u5DF2\u88AB\u5176\u4ED6\u7A97\u53E3\u66F4\u65B0\u6216\u7248\u672C\u5DF2\u8FBE\u4E0A\u9650\uFF1B\u8349\u7A3F\u5DF2\u4FDD\u7559\uFF0C\u8BF7\u660E\u786E\u91CD\u65B0\u52A0\u8F7D\u540E\u6838\u5BF9\u3002"
  );
  if (row.version !== input.expectedVersion) throw conflict();
  if ("status" in input && input.status === row.status)
    return findStudent(db, input.id, true);
  if (row.version >= 4294967295) throw conflict();
  const full = "name" in input;
  const result = await executeWrite(
    db,
    "UPDATE students SET " + (full ? "name=?,grade=?,school=?,class_name=?,gender=?,enrolled_at=?,guardian_name=?,guardian_phone=?,note=?" : "status=?") + ",version=version+1,updated_at=UTC_TIMESTAMP(3) WHERE id=? AND version=? AND version<4294967295",
    [
      ...full ? values(input) : [input.status],
      input.id,
      input.expectedVersion
    ]
  );
  if (!result.affectedRows) throw conflict();
  return findStudent(db, input.id);
}

export { createStudent as c, findStudentEdit as f, updateStudent as u };
//# sourceMappingURL=student-profile.mjs.map
