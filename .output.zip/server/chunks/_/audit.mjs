import { randomUUID } from 'node:crypto';
import { m as executeWrite, p as positiveId } from './nitro.mjs';

const auditEntityTypes = [
  "student",
  "contract",
  "learning_record",
  "score_record",
  "attendance_record",
  "task",
  "task_assignment",
  "user_account"
];
const forbiddenAuditKey = /(password|hash|token|csrf|guardian|phone|content|body)/iu;
function assertAuditSummary(value, label) {
  if (value === void 0) return null;
  for (const [key, item] of Object.entries(value)) {
    if (!/^[a-z][a-zA-Z0-9_]{0,63}$/u.test(key) || forbiddenAuditKey.test(key))
      throw new Error(`${label}\u5305\u542B\u654F\u611F\u6216\u4E0D\u5141\u8BB8\u5B57\u6BB5\u3002`);
    const items = Array.isArray(item) ? item : [item];
    if (items.some(
      (entry) => !(entry === null || typeof entry === "string" || typeof entry === "number" || typeof entry === "boolean") || typeof entry === "string" && entry.length > 256
    ))
      throw new Error(`${label}\u683C\u5F0F\u65E0\u6548\u3002`);
  }
  return JSON.stringify(value);
}
function requestId(value) {
  const id = value != null ? value : randomUUID();
  if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/iu.test(
    id
  ))
    throw new Error("\u5BA1\u8BA1\u8BF7\u6C42\u6807\u8BC6\u65E0\u6548\u3002");
  return id;
}
async function writeAuditLog(connection, input) {
  if (!/^[a-z][a-z0-9_.]{2,63}$/u.test(input.action))
    throw new Error("\u5BA1\u8BA1\u52A8\u4F5C\u65E0\u6548\u3002");
  if (!auditEntityTypes.includes(input.entityType))
    throw new Error("\u5BA1\u8BA1\u5BF9\u8C61\u65E0\u6548\u3002");
  const result = await executeWrite(
    connection,
    "INSERT INTO audit_logs (request_id,actor_user_id,action,entity_type,entity_id,student_id,before_json,after_json,metadata_json) VALUES (?,?,?,?,?,?,?,?,?)",
    [
      requestId(input.requestId),
      positiveId(input.actorUserId),
      input.action,
      input.entityType,
      positiveId(input.entityId),
      input.studentId === void 0 || input.studentId === null ? null : positiveId(input.studentId),
      assertAuditSummary(input.before, "\u5BA1\u8BA1\u524D\u503C"),
      assertAuditSummary(input.after, "\u5BA1\u8BA1\u540E\u503C"),
      assertAuditSummary(input.metadata, "\u5BA1\u8BA1\u5143\u6570\u636E")
    ]
  );
  return String(result.insertId);
}

export { writeAuditLog as w };
//# sourceMappingURL=audit.mjs.map
