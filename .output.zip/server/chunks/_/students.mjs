import { l as shanghaiToday, A as ApiError, h as studentGrades, j as dateOnly, Q as studentStatuses, k as uint, p as positiveId, R as studentFilter } from './nitro.mjs';
import { s as studentContractAggregates } from './contracts.mjs';
import { s as studentPlanTags } from './study-plans.mjs';

function invalid(message) {
  throw new ApiError(400, "VALIDATION_ERROR", message);
}
function object(value, fields2) {
  if (!value || typeof value !== "object" || Array.isArray(value))
    invalid("\u8BF7\u63D0\u4EA4\u6709\u6548\u6863\u6848\u5BF9\u8C61\u3002");
  const input = value;
  if (Object.keys(input).some((key) => !fields2.includes(key)))
    invalid("\u8BF7\u6C42\u5305\u542B\u4E0D\u53EF\u5199\u5B57\u6BB5\u3002");
  return input;
}
const fields = [
  "name",
  "grade",
  "school",
  "className",
  "gender",
  "enrolledAt",
  "guardianName",
  "guardianPhone",
  "note"
];
function text(value, max, label, required = false) {
  if (value === void 0 || value === null) {
    if (required) invalid("\u8BF7\u8F93\u5165" + label + "\u3002");
    return null;
  }
  if (typeof value !== "string") invalid(label + "\u683C\u5F0F\u65E0\u6548\u3002");
  const trimmed = value.trim();
  if ([...trimmed].length > max) invalid(label + "\u4E0D\u80FD\u8D85\u8FC7" + max + "\u4E2A\u5B57\u7B26\u3002");
  if (!trimmed && required) invalid("\u8BF7\u8F93\u5165" + label + "\u3002");
  return trimmed || null;
}
function profile(input, today) {
  var _a, _b, _c, _d;
  const name = text(input.name, 64, "\u5B66\u751F\u59D3\u540D", true);
  const grade = (_a = input.grade) != null ? _a : null;
  if (grade !== null && !studentGrades.some((v) => v === grade))
    invalid("\u8BF7\u9009\u62E9\u6709\u6548\u5E74\u7EA7\u3002");
  const gender = (_b = input.gender) != null ? _b : null;
  if (gender !== null && gender !== "\u7537" && gender !== "\u5973")
    invalid("\u6027\u522B\u53D6\u503C\u65E0\u6548\u3002");
  const enrolledAt = input.enrolledAt === void 0 || input.enrolledAt === null || input.enrolledAt === "" ? null : dateOnly(input.enrolledAt);
  if (enrolledAt && (enrolledAt < "1900-01-01" || enrolledAt > today))
    invalid("\u5165\u5B66\u65E5\u671F\u987B\u57281900-01-01\u81F3\u4ECA\u5929\u4E4B\u95F4\u3002");
  const guardianPhone = text(input.guardianPhone, 32, "\u8054\u7CFB\u65B9\u5F0F");
  if (guardianPhone && (!/^[0-9 +()-]+$/.test(guardianPhone) || ((_d = (_c = guardianPhone.match(/\d/g)) == null ? void 0 : _c.length) != null ? _d : 0) < 6))
    invalid("\u8054\u7CFB\u65B9\u5F0F\u683C\u5F0F\u4E0D\u6B63\u786E\u3002");
  return {
    name,
    grade,
    gender,
    enrolledAt,
    guardianPhone,
    school: text(input.school, 128, "\u5B66\u6821"),
    className: text(input.className, 32, "\u73ED\u7EA7"),
    guardianName: text(input.guardianName, 64, "\u76D1\u62A4\u4EBA\u59D3\u540D"),
    note: text(input.note, 500, "\u5907\u6CE8")
  };
}
function parseStudentCreate(value, today = shanghaiToday()) {
  const input = object(value, [...fields, "confirmPossibleDuplicate"]);
  if (input.confirmPossibleDuplicate !== void 0 && typeof input.confirmPossibleDuplicate !== "boolean")
    invalid("\u91CD\u590D\u786E\u8BA4\u53C2\u6570\u65E0\u6548\u3002");
  return {
    ...profile(input, today),
    confirmPossibleDuplicate: input.confirmPossibleDuplicate
  };
}
function parseStudentUpdate(value, today = shanghaiToday()) {
  const input = object(value, [...fields, "id", "expectedVersion"]);
  return {
    ...profile(input, today),
    id: positiveId(input.id),
    expectedVersion: uint(input.expectedVersion, "\u7248\u672C\u53F7", true)
  };
}
function parseStudentStatus(value) {
  const input = object(value, ["id", "status", "expectedVersion"]);
  if (!studentStatuses.some((v) => v === input.status))
    invalid("\u5B66\u751F\u72B6\u6001\u65E0\u6548\u3002");
  return {
    id: positiveId(input.id),
    expectedVersion: uint(input.expectedVersion, "\u7248\u672C\u53F7", true),
    status: input.status
  };
}
function maskGuardianPhone(value) {
  if (value === null) return null;
  if (/^\d{11}$/.test(value))
    return value.slice(0, 3) + "****" + value.slice(-4);
  const chars = [...value];
  if (chars.length < 5) return "*";
  return chars.slice(0, 2).join("") + "*".repeat(chars.length - 4) + chars.slice(-2).join("");
}

function toStudentListItem(row) {
  var _a;
  return {
    id: String(row.id),
    name: row.name,
    grade: row.grade,
    className: row.class_name,
    school: row.school,
    status: row.status,
    subjects: [],
    plans: [],
    expiryDate: null,
    lastFollowUp: (_a = row.last_follow_up) != null ? _a : null
  };
}
function toStudentDetail(row) {
  var _a;
  return {
    ...toStudentListItem(row),
    gender: row.gender,
    enrolledAt: row.enrolled_at,
    createdAt: row.created_at.replace(" ", "T") + "Z",
    guardianName: row.guardian_name,
    guardianPhoneMasked: maskGuardianPhone(row.guardian_phone),
    version: row.version,
    note: row.note,
    owner: row.owner_id ? { id: String(row.owner_id), name: (_a = row.owner_name) != null ? _a : "" } : null
  };
}
async function listStudents(connection, query, options = false) {
  var _a, _b;
  const filter = studentFilter(query);
  const [counts] = await connection.execute(
    "SELECT COUNT(*) AS total FROM students s" + filter.sql,
    filter.values
  );
  const columns = options ? "s.id, s.name, s.grade" : "s.id, s.name, s.grade, s.class_name, s.school, s.status, lr.last_follow_up";
  const join = options ? "" : " LEFT JOIN (SELECT student_id, MAX(occurred_on) AS last_follow_up FROM student_learning_records GROUP BY student_id) lr ON lr.student_id=s.id";
  const [rows] = await connection.execute(
    "SELECT " + columns + " FROM students s" + join + filter.sql + (options ? " ORDER BY s.id DESC" : " ORDER BY lr.last_follow_up DESC, s.id DESC") + " LIMIT ? OFFSET ?",
    [...filter.values, query.pageSize, (query.page - 1) * query.pageSize]
  );
  const aggregates = options ? void 0 : await studentContractAggregates(
    connection,
    rows.map((row) => String(row.id))
  );
  const plans = options ? void 0 : await studentPlanTags(
    connection,
    rows.map((row) => String(row.id))
  );
  return {
    items: options ? rows.map((row) => ({
      id: String(row.id),
      name: row.name,
      grade: row.grade
    })) : rows.map((row) => {
      var _a2;
      return {
        ...toStudentListItem(row),
        ...aggregates == null ? void 0 : aggregates.get(String(row.id)),
        plans: (_a2 = plans == null ? void 0 : plans.get(String(row.id))) != null ? _a2 : []
      };
    }),
    total: Number((_b = (_a = counts[0]) == null ? void 0 : _a.total) != null ? _b : 0),
    page: query.page,
    pageSize: query.pageSize
  };
}
async function findStudent(connection, id, currentRead = false) {
  var _a;
  const [rows] = await connection.execute(
    "SELECT s.id, s.name, s.grade, s.class_name, s.school, s.status, s.gender, s.enrolled_at, s.created_at, s.guardian_name, s.guardian_phone, s.note, s.version, u.id AS owner_id, u.name AS owner_name, (SELECT MAX(occurred_on) FROM student_learning_records WHERE student_id=s.id) AS last_follow_up FROM students s LEFT JOIN users u ON u.id = s.owner_user_id WHERE s.id = ? LIMIT 1" + (currentRead ? " FOR SHARE" : ""),
    [id]
  );
  if (!rows[0]) throw new ApiError(404, "NOT_FOUND", "\u672A\u627E\u5230\u5B66\u751F\u3002");
  const aggregates = await studentContractAggregates(connection, [id]);
  const plans = await studentPlanTags(connection, [id]);
  return {
    ...toStudentDetail(rows[0]),
    ...aggregates.get(id),
    plans: (_a = plans.get(id)) != null ? _a : []
  };
}
async function studentOptionsByIds(connection, ids) {
  const [rows] = await connection.execute(
    "SELECT id,name,grade FROM students WHERE id IN (" + ids.map(() => "?").join(",") + ") ORDER BY id LIMIT 100",
    ids
  );
  const items = rows.map((row) => ({
    id: String(row.id),
    name: row.name,
    grade: row.grade
  }));
  return { items, total: items.length, page: 1, pageSize: 100 };
}

export { parseStudentStatus as a, parseStudentUpdate as b, findStudent as f, listStudents as l, parseStudentCreate as p, studentOptionsByIds as s };
//# sourceMappingURL=students.mjs.map
