import { M as requiredSubject, p as positiveId, A as ApiError, L as parseStudentQuery, k as uint } from './nitro.mjs';

const taskStatuses = ["enabled", "disabled"];

function invalid(message = "\u4EFB\u52A1\u53C2\u6570\u65E0\u6548\u3002") {
  throw new ApiError(400, "VALIDATION_ERROR", message);
}
function object(value, fields) {
  if (!value || typeof value !== "object" || Array.isArray(value)) invalid();
  const input = value;
  if (Object.keys(input).some((key) => !fields.includes(key)))
    invalid("\u8BF7\u6C42\u542B\u4E0D\u53EF\u5199\u5B57\u6BB5\uFF0C\u64CD\u4F5C\u4EBA\u4E0D\u80FD\u7531\u6D4F\u89C8\u5668\u63D0\u4F9B\u3002");
  return input;
}
function text(value, max, name) {
  if (typeof value !== "string") invalid(name + "\u4E0D\u80FD\u4E3A\u7A7A\u3002");
  const trimmed = value.trim();
  if (!trimmed || [...trimmed].length > max)
    invalid(name + "\u987B\u4E3A1\u2013" + max + "\u5B57\u7B26\u3002");
  return trimmed;
}
function status(value) {
  if (!taskStatuses.some((item) => item === value))
    invalid("\u4EFB\u52A1\u72B6\u6001\u53EA\u80FD\u4E3A\u542F\u7528\u6216\u505C\u7528\u3002");
  return value;
}
function studyPlanId(value) {
  if (value === void 0) return void 0;
  if (value === null) return null;
  return positiveId(value);
}
function parseTaskWrite(value) {
  const input = object(value, [
    "title",
    "subject",
    "description",
    "studyPlanId"
  ]);
  return {
    title: text(input.title, 160, "\u4EFB\u52A1\u540D\u79F0"),
    subject: requiredSubject(input.subject),
    description: text(input.description, 1e4, "\u4EFB\u52A1\u8BF4\u660E"),
    studyPlanId: studyPlanId(input.studyPlanId)
  };
}
function parseTaskUpdate(value) {
  const input = object(value, [
    "id",
    "title",
    "subject",
    "description",
    "status",
    "expectedVersion",
    "studyPlanId"
  ]);
  return {
    ...parseTaskWrite({
      title: input.title,
      subject: input.subject,
      description: input.description
    }),
    id: positiveId(input.id),
    status: status(input.status),
    expectedVersion: uint(input.expectedVersion, "\u7248\u672C\u53F7", true),
    studyPlanId: studyPlanId(input.studyPlanId)
  };
}
function parseTaskStatus(value) {
  const input = object(value, ["id", "status", "expectedVersion"]);
  return {
    id: positiveId(input.id),
    status: status(input.status),
    expectedVersion: uint(input.expectedVersion, "\u7248\u672C\u53F7", true)
  };
}
function parseTaskQuery(value, options = false) {
  const input = object(value, [
    "page",
    "pageSize",
    "keyword",
    ...options ? [] : ["subject", "status"]
  ]);
  const page = parseStudentQuery(
    { page: input.page, pageSize: input.pageSize, keyword: input.keyword },
    options
  );
  return {
    page: page.page,
    pageSize: page.pageSize,
    keyword: page.keyword,
    ...input.subject === void 0 ? {} : { subject: requiredSubject(input.subject) },
    ...input.status === void 0 ? {} : { status: status(input.status) }
  };
}

export { parseTaskQuery as a, parseTaskStatus as b, parseTaskUpdate as c, parseTaskWrite as p };
//# sourceMappingURL=task-rules.mjs.map
