import { m as executeWrite, A as ApiError, j as dateOnly, K as optionalSubject, k as uint, p as positiveId, l as shanghaiToday, L as parseStudentQuery, M as requiredSubject } from './nitro.mjs';
import { l as likeValue } from './contracts.mjs';

function projectRecord(row) {
  return {
    id: String(row.id),
    studentId: String(row.student_id),
    author: { id: String(row.author_user_id), name: row.author_name },
    category: row.category,
    subject: row.subject,
    content: row.content,
    occurredOn: row.occurred_on,
    createdAt: row.created_at.replace(" ", "T") + "Z",
    updatedAt: row.updated_at.replace(" ", "T") + "Z",
    version: row.version
  };
}
const selection = "SELECT r.id, r.student_id, r.author_user_id, u.name AS author_name, r.category, r.subject, r.content, r.occurred_on, r.created_at, r.updated_at, r.version FROM student_learning_records r JOIN users u ON u.id=r.author_user_id";
async function requireRecordStudent(db, id) {
  const [rows] = await db.execute(
    "SELECT id FROM students WHERE id=? LIMIT 1",
    [id]
  );
  if (!rows.length)
    throw new ApiError(404, "STUDENT_NOT_FOUND", "\u672A\u627E\u5230\u5B66\u751F\u3002");
}
function recordFilter(query) {
  const clauses = ["r.student_id = ?"], values = [query.studentId];
  if (query.category) {
    clauses.push("r.category = ?");
    values.push(query.category);
  }
  if (query.subject) {
    clauses.push("r.subject = ?");
    values.push(query.subject);
  }
  if (query.dateFrom) {
    clauses.push("r.occurred_on >= ?");
    values.push(query.dateFrom);
  }
  if (query.dateTo) {
    clauses.push("r.occurred_on <= ?");
    values.push(query.dateTo);
  }
  if (query.keyword) {
    clauses.push("r.content LIKE ? ESCAPE '!'");
    values.push(likeValue(query.keyword));
  }
  return { sql: " WHERE " + clauses.join(" AND "), values };
}
async function listRecords(db, query) {
  await requireRecordStudent(db, query.studentId);
  const filter = recordFilter(query);
  const [counts] = await db.execute(
    "SELECT COUNT(*) AS total FROM student_learning_records r" + filter.sql,
    filter.values
  );
  const [rows] = await db.execute(
    selection + filter.sql + " ORDER BY r.created_at DESC,r.id DESC LIMIT ? OFFSET ?",
    [...filter.values, query.pageSize, (query.page - 1) * query.pageSize]
  );
  return {
    items: rows.map(projectRecord),
    total: Number(counts[0].total),
    page: query.page,
    pageSize: query.pageSize
  };
}
async function findRecord(db, id) {
  const [rows] = await db.execute(
    selection + " WHERE r.id=? LIMIT 1",
    [id]
  );
  if (!rows[0]) throw new ApiError(404, "NOT_FOUND", "\u672A\u627E\u5230\u5B66\u4E60\u8BB0\u5F55\u3002");
  return projectRecord(rows[0]);
}
async function createRecord(db, input, actorId) {
  await requireRecordStudent(db, input.studentId);
  const result = await executeWrite(
    db,
    "INSERT INTO student_learning_records (student_id,author_user_id,category,subject,content,occurred_on) VALUES (?,?,?,?,?,?)",
    [
      input.studentId,
      actorId,
      input.category,
      input.subject,
      input.content,
      input.occurredOn
    ]
  );
  return findRecord(db, String(result.insertId));
}
async function updateRecord(db, input) {
  const result = await executeWrite(
    db,
    "UPDATE student_learning_records SET category=?,subject=?,content=?,occurred_on=?,version=version+1,updated_at=UTC_TIMESTAMP(3) WHERE id=? AND version=? AND version<4294967295",
    [
      input.category,
      input.subject,
      input.content,
      input.occurredOn,
      input.id,
      input.expectedVersion
    ]
  );
  if (!result.affectedRows) {
    await findRecord(db, input.id);
    throw new ApiError(
      409,
      "VERSION_CONFLICT",
      "\u8BB0\u5F55\u5DF2\u88AB\u4FEE\u6539\uFF0C\u8BF7\u4FDD\u7559\u8349\u7A3F\u5E76\u91CD\u65B0\u8F7D\u5165\u6700\u65B0\u7248\u672C\u3002"
    );
  }
  return findRecord(db, input.id);
}

const recordCategories = ["\u7F3A", "\u8865", "\u5F3A"];

function invalid(message) {
  throw new ApiError(400, "VALIDATION_ERROR", message);
}
function category(value) {
  if (!recordCategories.some((v) => v === value))
    invalid("\u5206\u7C7B\u4EC5\u652F\u6301\u7F3A\u3001\u8865\u3001\u5F3A\u3002");
  return value;
}
function parseRecordWrite(body, update = false, today = shanghaiToday()) {
  if (!body || typeof body !== "object" || Array.isArray(body))
    invalid("\u8BB0\u5F55\u8BF7\u6C42\u987B\u4E3AJSON\u5BF9\u8C61\u3002");
  const input = body;
  const allowed = [
    "category",
    "subject",
    "content",
    "occurredOn",
    ...update ? ["id", "expectedVersion"] : ["studentId"]
  ];
  if (Object.keys(input).some((k) => !allowed.includes(k)))
    invalid("\u8BF7\u6C42\u542B\u4E0D\u53EF\u5199\u5B57\u6BB5\uFF0C\u4E0D\u80FD\u4FEE\u6539\u4F5C\u8005\u3001\u5B66\u751F\u5F52\u5C5E\u6216\u670D\u52A1\u7AEF\u7248\u672C\u3002");
  if (typeof input.content !== "string") invalid("\u6B63\u6587\u5FC5\u987B\u4E3A\u6587\u672C\u3002");
  const content = input.content.trim();
  if ([...content].length < 1 || [...content].length > 1e4)
    invalid("\u6B63\u6587\u53BB\u9664\u9996\u5C3E\u7A7A\u767D\u540E\u987B\u4E3A1\u201310000\u5B57\u3002");
  const occurredOn = dateOnly(input.occurredOn);
  if (occurredOn > today) invalid("\u53D1\u751F\u65E5\u671F\u4E0D\u5F97\u665A\u4E8E\u4ECA\u5929\u3002");
  const fields = {
    category: category(input.category),
    subject: input.subject === void 0 ? null : optionalSubject(input.subject),
    content,
    occurredOn
  };
  return update ? {
    ...fields,
    id: positiveId(input.id),
    expectedVersion: uint(input.expectedVersion, "\u7248\u672C\u53F7", true)
  } : { ...fields, studentId: positiveId(input.studentId) };
}
function parseRecordQuery(input) {
  var _a;
  if (Object.keys(input).some(
    (k) => ![
      "studentId",
      "page",
      "pageSize",
      "category",
      "subject",
      "keyword",
      "dateFrom",
      "dateTo"
    ].includes(k)
  ))
    invalid("\u67E5\u8BE2\u53C2\u6570\u65E0\u6548\u3002");
  const pagination = parseStudentQuery({
    page: input.page,
    pageSize: (_a = input.pageSize) != null ? _a : "5",
    keyword: input.keyword
  });
  const dateFrom = input.dateFrom === void 0 ? void 0 : dateOnly(input.dateFrom);
  const dateTo = input.dateTo === void 0 ? void 0 : dateOnly(input.dateTo);
  if (dateFrom && dateTo && dateFrom > dateTo)
    invalid("\u5F00\u59CB\u65E5\u671F\u4E0D\u5F97\u665A\u4E8E\u7ED3\u675F\u65E5\u671F\u3002");
  return {
    studentId: positiveId(input.studentId),
    page: pagination.page,
    pageSize: pagination.pageSize,
    keyword: pagination.keyword,
    category: input.category === void 0 ? void 0 : category(input.category),
    subject: input.subject === void 0 ? void 0 : requiredSubject(input.subject),
    dateFrom,
    dateTo
  };
}

export { parseRecordQuery as a, createRecord as c, listRecords as l, parseRecordWrite as p, updateRecord as u };
//# sourceMappingURL=learning-record-rules.mjs.map
