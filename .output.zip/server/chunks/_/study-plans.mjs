import { l as likeValue } from './contracts.mjs';
import { A as ApiError, m as executeWrite } from './nitro.mjs';
import { t as taskAssignmentCounts } from './task-assignments.mjs';

function projectPlanList(row) {
  return {
    id: String(row.id),
    title: row.title,
    summary: row.summary,
    updatedAt: row.updated_at.replace(" ", "T") + "Z",
    version: row.version
  };
}
function projectPlanDetail(row) {
  return {
    ...projectPlanList(row),
    content: row.content,
    createdAt: row.created_at.replace(" ", "T") + "Z",
    owner: { id: String(row.owner_user_id), name: row.owner_name },
    relatedTasks: [],
    studentProgress: []
  };
}
async function listPlans(db, query) {
  const where = query.keyword ? " WHERE (title LIKE ? ESCAPE '!' OR summary LIKE ? ESCAPE '!' OR content LIKE ? ESCAPE '!')" : "";
  const values = query.keyword ? Array(3).fill(likeValue(query.keyword)) : [];
  const [counts] = await db.execute(
    "SELECT COUNT(*) AS total FROM study_plan_documents" + where + " LIMIT 1",
    values
  );
  const [rows] = await db.execute(
    "SELECT id,title,summary,updated_at,version FROM study_plan_documents" + where + " ORDER BY updated_at DESC,id DESC LIMIT ? OFFSET ?",
    [...values, query.pageSize, (query.page - 1) * query.pageSize]
  );
  return {
    items: rows.map(projectPlanList),
    total: Number(counts[0].total),
    page: query.page,
    pageSize: query.pageSize
  };
}
async function listPlanOptions(db, query) {
  const where = query.keyword ? " WHERE title LIKE ? ESCAPE '!' OR summary LIKE ? ESCAPE '!'" : "";
  const values = query.keyword ? [likeValue(query.keyword), likeValue(query.keyword)] : [];
  const [counts] = await db.execute(
    "SELECT COUNT(*) AS total FROM study_plan_documents" + where + " LIMIT 1",
    values
  );
  const [rows] = await db.execute(
    "SELECT id,title FROM study_plan_documents" + where + " ORDER BY updated_at DESC,id DESC LIMIT ? OFFSET ?",
    [...values, query.pageSize, (query.page - 1) * query.pageSize]
  );
  return {
    items: rows.map((row) => ({
      id: String(row.id),
      title: String(row.title)
    })),
    total: Number(counts[0].total),
    page: query.page,
    pageSize: query.pageSize
  };
}
function progress(plan, completedAssignments, totalAssignments) {
  return {
    plan,
    completedAssignments,
    totalAssignments,
    progressPercent: totalAssignments ? Math.round(completedAssignments / totalAssignments * 100) : null,
    progressState: totalAssignments ? "active" : "empty"
  };
}
async function planStudentProgress(db, plan) {
  const [rows] = await db.execute(
    "SELECT ps.student_id,s.name AS student_name,s.grade,COALESCE(a.completed_assignments,0) AS completed_assignments,COALESCE(a.total_assignments,0) AS total_assignments FROM study_plan_students ps JOIN students s ON s.id=ps.student_id LEFT JOIN (SELECT student_id,SUM(status='completed') AS completed_assignments,COUNT(*) AS total_assignments FROM task_assignments WHERE study_plan_id_snapshot=? GROUP BY student_id) a ON a.student_id=ps.student_id WHERE ps.plan_id=? ORDER BY s.name,s.id LIMIT 100",
    [plan.id, plan.id]
  );
  return rows.map((row) => ({
    student: {
      id: String(row.student_id),
      name: row.student_name,
      grade: row.grade
    },
    ...progress(
      plan,
      Number(row.completed_assignments),
      Number(row.total_assignments)
    )
  }));
}
async function relatedPlanTasks(db, plan) {
  const [rows] = await db.execute(
    "SELECT id,title,subject,description,status,version,created_at,updated_at FROM tasks WHERE study_plan_id=? ORDER BY updated_at DESC,id DESC LIMIT 100",
    [plan.id]
  );
  const counts = await taskAssignmentCounts(
    db,
    rows.map((row) => String(row.id))
  );
  return rows.map((row) => {
    var _a;
    return {
      id: String(row.id),
      title: row.title,
      subject: row.subject,
      description: row.description,
      status: row.status,
      version: row.version,
      createdAt: row.created_at.replace(" ", "T") + "Z",
      updatedAt: row.updated_at.replace(" ", "T") + "Z",
      assignmentCount: (_a = counts.get(String(row.id))) != null ? _a : 0,
      studyPlan: plan
    };
  });
}
async function findPlan(db, id) {
  const [rows] = await db.execute(
    "SELECT p.id,p.title,p.summary,p.content,p.version,p.created_at,p.updated_at,p.owner_user_id,u.name AS owner_name FROM study_plan_documents p JOIN users u ON u.id=p.owner_user_id WHERE p.id=? LIMIT 1",
    [id]
  );
  if (!rows[0]) throw new ApiError(404, "NOT_FOUND", "\u672A\u627E\u5230\u5B66\u4E60\u8BA1\u5212\u3002");
  const plan = projectPlanDetail(rows[0]);
  const tag = { id: plan.id, title: plan.title };
  const relatedTasks = await relatedPlanTasks(db, tag);
  const studentProgress = await planStudentProgress(db, tag);
  return { ...plan, relatedTasks, studentProgress };
}
async function updatePlan(db, input) {
  const result = await executeWrite(
    db,
    "UPDATE study_plan_documents SET content=?,updated_at=UTC_TIMESTAMP(3),version=version+1 WHERE id=? AND version=? AND version<4294967295",
    [input.content, input.id, input.expectedVersion]
  );
  if (!result.affectedRows) {
    await findPlan(db, input.id);
    throw new ApiError(
      409,
      "VERSION_CONFLICT",
      "\u8BA1\u5212\u5DF2\u88AB\u4FEE\u6539\uFF0C\u8349\u7A3F\u5DF2\u4FDD\u7559\uFF0C\u8BF7\u91CD\u8F7D\u6700\u65B0\u7248\u672C\u540E\u518D\u7F16\u8F91\u3002"
    );
  }
  return findPlan(db, input.id);
}
async function studentPlanProgress(db, studentId) {
  const [students] = await db.execute(
    "SELECT id FROM students WHERE id=? LIMIT 1",
    [studentId]
  );
  if (!students.length) throw new ApiError(404, "NOT_FOUND", "\u672A\u627E\u5230\u5B66\u751F\u3002");
  const [rows] = await db.execute(
    "SELECT ps.plan_id,p.title,COALESCE(a.completed_assignments,0) AS completed_assignments,COALESCE(a.total_assignments,0) AS total_assignments FROM study_plan_students ps JOIN study_plan_documents p ON p.id=ps.plan_id LEFT JOIN (SELECT study_plan_id_snapshot,SUM(status='completed') AS completed_assignments,COUNT(*) AS total_assignments FROM task_assignments WHERE student_id=? AND study_plan_id_snapshot IS NOT NULL GROUP BY study_plan_id_snapshot) a ON a.study_plan_id_snapshot=ps.plan_id WHERE ps.student_id=? ORDER BY p.id LIMIT 100",
    [studentId, studentId]
  );
  return rows.map(
    (row) => progress(
      { id: String(row.plan_id), title: row.title },
      Number(row.completed_assignments),
      Number(row.total_assignments)
    )
  );
}
async function studentPlanTags(db, ids) {
  const result = /* @__PURE__ */ new Map();
  if (!ids.length) return result;
  const [rows] = await db.execute(
    "SELECT ps.student_id,JSON_ARRAYAGG(JSON_OBJECT('id',CAST(p.id AS CHAR),'title',p.title)) AS plans FROM study_plan_students ps JOIN study_plan_documents p ON p.id=ps.plan_id WHERE ps.student_id IN (" + ids.map(() => "?").join(",") + ") GROUP BY ps.student_id LIMIT ?",
    [...ids, ids.length]
  );
  for (const row of rows) {
    const plans = typeof row.plans === "string" ? JSON.parse(row.plans) : row.plans;
    result.set(
      String(row.student_id),
      plans.sort(
        (a, b) => a.id.length - b.id.length || a.id.localeCompare(b.id)
      )
    );
  }
  return result;
}

export { studentPlanProgress as a, listPlanOptions as b, findPlan as f, listPlans as l, studentPlanTags as s, updatePlan as u };
//# sourceMappingURL=study-plans.mjs.map
