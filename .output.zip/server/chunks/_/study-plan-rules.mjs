import { L as parseStudentQuery, A as ApiError, k as uint, p as positiveId } from './nitro.mjs';

function parsePlanQuery(query) {
  return parseStudentQuery(query, true);
}
function parsePlanUpdate(body) {
  if (!body || typeof body !== "object" || Array.isArray(body))
    throw new ApiError(400, "VALIDATION_ERROR", "\u6B63\u6587\u66F4\u65B0\u987B\u4E3AJSON\u5BF9\u8C61\u3002");
  const input = body;
  if (Object.keys(input).some(
    (key) => !["id", "content", "expectedVersion"].includes(key)
  ))
    throw new ApiError(
      400,
      "VALIDATION_ERROR",
      "\u4EC5\u5141\u8BB8\u4FEE\u6539\u6B63\u6587\uFF0C\u8D1F\u8D23\u4EBA\u3001\u6807\u9898\u548C\u6458\u8981\u4E0D\u53EF\u4FEE\u6539\u3002"
    );
  if (typeof input.content !== "string" || !input.content.trim() || [...input.content.trim()].length > 1e5)
    throw new ApiError(
      400,
      "VALIDATION_ERROR",
      "\u6B63\u6587\u53BB\u9664\u9996\u5C3E\u7A7A\u767D\u540E\u987B\u4E3A1\u2013100000\u5B57\u7B26\u3002"
    );
  return {
    id: positiveId(input.id),
    content: input.content,
    expectedVersion: uint(input.expectedVersion, "\u7248\u672C\u53F7", true)
  };
}

export { parsePlanUpdate as a, parsePlanQuery as p };
//# sourceMappingURL=study-plan-rules.mjs.map
