import { m as executeWrite, A as ApiError } from './nitro.mjs';
import { l as likeValue } from './contracts.mjs';
import { w as writeAuditLog } from './audit.mjs';

const selection = "SELECT r.id,r.student_id,s.name AS student_name,r.exam_date,r.subject,r.record_type,r.exam_name,r.score,r.full_score,CAST(ROUND((r.score / r.full_score) * 100,2) AS CHAR) AS score_rate,r.created_at,r.updated_at,r.version FROM score_records r JOIN students s ON s.id=r.student_id";
function toIso(value) {
  return value.replace(" ", "T") + "Z";
}
function projectScoreRecord(row) {
  return {
    id: String(row.id),
    studentId: String(row.student_id),
    studentName: row.student_name,
    examDate: row.exam_date,
    subject: row.subject,
    type: row.record_type,
    examName: row.exam_name,
    score: String(row.score),
    fullScore: String(row.full_score),
    scoreRate: String(row.score_rate),
    createdAt: toIso(row.created_at),
    updatedAt: toIso(row.updated_at),
    version: row.version
  };
}
async function requireScoreStudent(connection, studentId) {
  const [rows] = await connection.execute(
    "SELECT id FROM students WHERE id=? LIMIT 1",
    [studentId]
  );
  if (!rows.length) throw new ApiError(404, "NOT_FOUND", "\u672A\u627E\u5230\u6240\u9009\u5B66\u751F\u3002");
}
function scoreRecordFilter(query) {
  const clauses = [];
  const values = [];
  if (query.keyword) {
    clauses.push("(s.name LIKE ? ESCAPE '!' OR r.exam_name LIKE ? ESCAPE '!')");
    values.push(likeValue(query.keyword), likeValue(query.keyword));
  }
  if (query.studentId) {
    clauses.push("r.student_id=?");
    values.push(query.studentId);
  }
  if (query.subject) {
    clauses.push("r.subject=?");
    values.push(query.subject);
  }
  if (query.type) {
    clauses.push("r.record_type=?");
    values.push(query.type);
  }
  if (query.dateFrom) {
    clauses.push("r.exam_date>=?");
    values.push(query.dateFrom);
  }
  if (query.dateTo) {
    clauses.push("r.exam_date<=?");
    values.push(query.dateTo);
  }
  return {
    sql: clauses.length ? " WHERE " + clauses.join(" AND ") : "",
    values
  };
}
async function listScoreRecords(connection, query) {
  var _a, _b;
  const filter = scoreRecordFilter(query);
  const from = " FROM score_records r JOIN students s ON s.id=r.student_id";
  const [counts] = await connection.execute(
    "SELECT COUNT(*) AS total" + from + filter.sql,
    filter.values
  );
  const [rows] = await connection.execute(
    selection + filter.sql + " ORDER BY r.exam_date DESC,r.id DESC LIMIT ? OFFSET ?",
    [...filter.values, query.pageSize, (query.page - 1) * query.pageSize]
  );
  return {
    items: rows.map(projectScoreRecord),
    total: Number((_b = (_a = counts[0]) == null ? void 0 : _a.total) != null ? _b : 0),
    page: query.page,
    pageSize: query.pageSize
  };
}
async function findScoreRecord(connection, id, locked = false) {
  const [rows] = await connection.execute(
    selection + " WHERE r.id=? LIMIT 1" + (locked ? " FOR SHARE" : ""),
    [id]
  );
  if (!rows[0]) throw new ApiError(404, "NOT_FOUND", "\u672A\u627E\u5230\u6210\u7EE9\u8BB0\u5F55\u3002");
  return projectScoreRecord(rows[0]);
}
async function scoreRecordSubjects(connection, query) {
  var _a, _b;
  const where = query.keyword ? " WHERE subject LIKE ? ESCAPE '!'" : "";
  const values = query.keyword ? [likeValue(query.keyword)] : [];
  const [counts] = await connection.execute(
    "SELECT COUNT(DISTINCT subject) AS total FROM score_records" + where,
    values
  );
  const [rows] = await connection.execute(
    "SELECT DISTINCT subject AS value FROM score_records" + where + " ORDER BY value LIMIT ? OFFSET ?",
    [...values, query.pageSize, (query.page - 1) * query.pageSize]
  );
  return {
    items: rows.map((row) => ({ value: String(row.value) })),
    total: Number((_b = (_a = counts[0]) == null ? void 0 : _a.total) != null ? _b : 0),
    page: query.page,
    pageSize: query.pageSize
  };
}
function auditSummary(record) {
  return {
    studentId: record.studentId,
    examDate: record.examDate,
    subject: record.subject,
    type: record.type,
    examName: record.examName,
    score: record.score,
    fullScore: record.fullScore
  };
}
async function createScoreRecord(connection, input, actorId) {
  await requireScoreStudent(connection, input.studentId);
  const result = await executeWrite(
    connection,
    "INSERT INTO score_records (student_id,exam_date,subject,record_type,exam_name,score,full_score,created_by,updated_by) VALUES (?,?,?,?,?,?,?,?,?)",
    [
      input.studentId,
      input.examDate,
      input.subject,
      input.type,
      input.examName,
      input.score,
      input.fullScore,
      actorId,
      actorId
    ]
  );
  const record = await findScoreRecord(connection, String(result.insertId));
  await writeAuditLog(connection, {
    actorUserId: actorId,
    action: "score_record.create",
    entityType: "score_record",
    entityId: record.id,
    studentId: record.studentId,
    after: auditSummary(record)
  });
  return record;
}
async function updateScoreRecord(connection, input, actorId) {
  const before = await findScoreRecord(connection, input.id, true);
  if (before.version !== input.expectedVersion || before.version >= 4294967295)
    throw new ApiError(
      409,
      "VERSION_CONFLICT",
      "\u6210\u7EE9\u8BB0\u5F55\u5DF2\u88AB\u4FEE\u6539\uFF0C\u8BF7\u4FDD\u7559\u8349\u7A3F\u5E76\u91CD\u65B0\u8F7D\u5165\u6700\u65B0\u7248\u672C\u3002"
    );
  await requireScoreStudent(connection, input.studentId);
  const result = await executeWrite(
    connection,
    "UPDATE score_records SET student_id=?,exam_date=?,subject=?,record_type=?,exam_name=?,score=?,full_score=?,updated_by=?,version=version+1,updated_at=UTC_TIMESTAMP(3) WHERE id=? AND version=? AND version<4294967295",
    [
      input.studentId,
      input.examDate,
      input.subject,
      input.type,
      input.examName,
      input.score,
      input.fullScore,
      actorId,
      input.id,
      input.expectedVersion
    ]
  );
  if (!result.affectedRows) {
    await findScoreRecord(connection, input.id);
    throw new ApiError(
      409,
      "VERSION_CONFLICT",
      "\u6210\u7EE9\u8BB0\u5F55\u5DF2\u88AB\u4FEE\u6539\uFF0C\u8BF7\u4FDD\u7559\u8349\u7A3F\u5E76\u91CD\u65B0\u8F7D\u5165\u6700\u65B0\u7248\u672C\u3002"
    );
  }
  const record = await findScoreRecord(connection, input.id);
  await writeAuditLog(connection, {
    actorUserId: actorId,
    action: "score_record.update",
    entityType: "score_record",
    entityId: record.id,
    studentId: record.studentId,
    before: auditSummary(before),
    after: auditSummary(record)
  });
  return record;
}

export { createScoreRecord as c, findScoreRecord as f, listScoreRecords as l, scoreRecordSubjects as s, updateScoreRecord as u };
//# sourceMappingURL=score-records.mjs.map
