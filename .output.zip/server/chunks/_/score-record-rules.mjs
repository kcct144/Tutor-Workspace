import { j as dateOnly, M as requiredSubject, p as positiveId, k as uint, l as shanghaiToday, A as ApiError, L as parseStudentQuery } from './nitro.mjs';

const scoreRecordTypes = ["quiz", "exam"];

function invalid(message) {
  throw new ApiError(400, "VALIDATION_ERROR", message);
}
function scoreType(value) {
  if (!scoreRecordTypes.includes(value))
    invalid("\u6210\u7EE9\u7C7B\u578B\u4EC5\u652F\u6301\u5C0F\u6D4B\u6216\u8003\u8BD5\u3002");
  return value;
}
function text(value, name, max) {
  if (typeof value !== "string") invalid(name + "\u5FC5\u987B\u4E3A\u6587\u672C\u3002");
  const normalized = value.trim();
  if (!normalized || [...normalized].length > max)
    invalid(name + "\u987B\u4E3A1\u2013" + max + "\u5B57\u7B26\u3002");
  return normalized;
}
function decimal(value, name) {
  var _a;
  if (typeof value !== "string") invalid(name + "\u987B\u4E3A\u6700\u591A\u4E24\u4F4D\u5C0F\u6570\u7684\u6570\u5B57\u3002");
  const normalized = value.trim();
  const match = /^(0|[1-9]\d{0,7})(?:\.(\d{1,2}))?$/u.exec(normalized);
  if (!match) invalid(name + "\u987B\u4E3A\u6700\u591A\u4E24\u4F4D\u5C0F\u6570\u7684\u975E\u8D1F\u6570\u5B57\u3002");
  const fraction = ((_a = match[2]) != null ? _a : "").padEnd(2, "0");
  return {
    value: normalized,
    // The grammar limits this to 9,999,999,999 cents, within safe integers.
    cents: Number(match[1]) * 100 + Number(fraction || "0")
  };
}
function parseScoreRecordWrite(body, update = false, today = shanghaiToday()) {
  if (!body || typeof body !== "object" || Array.isArray(body))
    invalid("\u6210\u7EE9\u8BF7\u6C42\u987B\u4E3AJSON\u5BF9\u8C61\u3002");
  const input = body;
  const allowed = [
    "studentId",
    "examDate",
    "subject",
    "type",
    "examName",
    "score",
    "fullScore",
    ...update ? ["id", "expectedVersion"] : []
  ];
  if (Object.keys(input).some((key) => !allowed.includes(key)))
    invalid("\u8BF7\u6C42\u542B\u4E0D\u53EF\u5199\u5B57\u6BB5\u3002");
  const examDate = dateOnly(input.examDate);
  if (examDate < "1900-01-01" || examDate > today)
    invalid("\u6210\u7EE9\u65E5\u671F\u987B\u57281900-01-01\u81F3\u4ECA\u5929\u4E4B\u95F4\u3002");
  const score = decimal(input.score, "\u5F97\u5206");
  const fullScore = decimal(input.fullScore, "\u6EE1\u5206");
  if (fullScore.cents <= 0) invalid("\u6EE1\u5206\u5FC5\u987B\u5927\u4E8E0\u3002");
  if (score.cents > fullScore.cents) invalid("\u5F97\u5206\u4E0D\u80FD\u5927\u4E8E\u6EE1\u5206\u3002");
  const fields = {
    studentId: positiveId(input.studentId),
    examDate,
    subject: requiredSubject(input.subject),
    type: scoreType(input.type),
    examName: text(input.examName, "\u8003\u8BD5\u540D\u79F0", 160),
    score: score.value,
    fullScore: fullScore.value
  };
  return update ? {
    ...fields,
    id: positiveId(input.id),
    expectedVersion: uint(input.expectedVersion, "\u7248\u672C\u53F7", true)
  } : fields;
}
function parseScoreRecordQuery(input) {
  var _a;
  const allowed = [
    "page",
    "pageSize",
    "keyword",
    "studentId",
    "subject",
    "type",
    "dateFrom",
    "dateTo"
  ];
  if (Object.keys(input).some((key) => !allowed.includes(key)))
    invalid("\u67E5\u8BE2\u53C2\u6570\u65E0\u6548\u3002");
  const pagination = parseStudentQuery({
    page: input.page,
    pageSize: (_a = input.pageSize) != null ? _a : "10",
    keyword: input.keyword
  });
  const dateFrom = input.dateFrom === void 0 ? void 0 : dateOnly(input.dateFrom);
  const dateTo = input.dateTo === void 0 ? void 0 : dateOnly(input.dateTo);
  if (dateFrom && dateFrom < "1900-01-01" || dateTo && dateTo < "1900-01-01" || dateFrom && dateTo && dateFrom > dateTo)
    invalid("\u65E5\u671F\u8303\u56F4\u65E0\u6548\u3002");
  return {
    ...pagination,
    studentId: input.studentId === void 0 ? void 0 : positiveId(input.studentId),
    subject: input.subject === void 0 ? void 0 : requiredSubject(input.subject),
    type: input.type === void 0 ? void 0 : scoreType(input.type),
    dateFrom,
    dateTo
  };
}
function parseScoreRecordSubjectQuery(input) {
  var _a;
  if (Object.keys(input).some(
    (key) => !["page", "pageSize", "keyword"].includes(key)
  ))
    invalid("\u67E5\u8BE2\u53C2\u6570\u65E0\u6548\u3002");
  return parseStudentQuery({
    page: input.page,
    pageSize: (_a = input.pageSize) != null ? _a : "20",
    keyword: input.keyword
  });
}

export { parseScoreRecordQuery as a, parseScoreRecordSubjectQuery as b, parseScoreRecordWrite as p };
//# sourceMappingURL=score-record-rules.mjs.map
