import { c as defineEventHandler, e as apiResponse, A as ApiError } from '../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'mysql2/promise';
import 'node:url';

const _____ = defineEventHandler(
  (event) => apiResponse(event, async () => {
    throw new ApiError(404, "API_NOT_FOUND", "API\u8DEF\u5F84\u6216\u8BF7\u6C42\u65B9\u6CD5\u4E0D\u5B58\u5728\u3002");
  })
);

export { _____ as default };
//# sourceMappingURL=_..._.mjs.map
