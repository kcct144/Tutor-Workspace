import { c as defineEventHandler, e as apiResponse, w as withDatabase, u as useRuntimeConfig, i as inTransaction, r as requireActiveAuth, f as setResponseStatus } from '../../../_/nitro.mjs';
import { p as parseRecordWrite, c as createRecord } from '../../../_/learning-record-rules.mjs';
import { j as jsonBody } from '../../../_/json-body.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'mysql2/promise';
import 'node:url';
import '../../../_/contracts.mjs';

const create_post = defineEventHandler(
  (event) => apiResponse(event, async () => {
    const input = parseRecordWrite(await jsonBody(event, 131072));
    const result = await withDatabase(
      useRuntimeConfig(event).mysql,
      (db) => inTransaction(
        db,
        async () => createRecord(db, input, (await requireActiveAuth(db, event)).userId)
      )
    );
    setResponseStatus(event, 201);
    return result;
  })
);

export { create_post as default };
//# sourceMappingURL=create.post.mjs.map
