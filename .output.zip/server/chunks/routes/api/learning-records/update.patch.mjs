import { c as defineEventHandler, e as apiResponse, w as withDatabase, u as useRuntimeConfig, i as inTransaction, r as requireActiveAuth } from '../../../_/nitro.mjs';
import { p as parseRecordWrite, u as updateRecord } from '../../../_/learning-record-rules.mjs';
import { j as jsonBody } from '../../../_/json-body.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'mysql2/promise';
import 'node:url';
import '../../../_/contracts.mjs';

const update_patch = defineEventHandler(
  (event) => apiResponse(event, async () => {
    const input = parseRecordWrite(await jsonBody(event, 131072), true);
    return withDatabase(
      useRuntimeConfig(event).mysql,
      (db) => inTransaction(db, async () => {
        await requireActiveAuth(db, event);
        return updateRecord(db, input);
      })
    );
  })
);

export { update_patch as default };
//# sourceMappingURL=update.patch.mjs.map
