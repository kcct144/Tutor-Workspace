import { c as defineEventHandler, e as apiResponse, g as getQuery, w as withDatabase, u as useRuntimeConfig, i as inTransaction } from '../../../_/nitro.mjs';
import { l as listScoreRecords } from '../../../_/score-records.mjs';
import { a as parseScoreRecordQuery } from '../../../_/score-record-rules.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'mysql2/promise';
import 'node:url';
import '../../../_/contracts.mjs';
import '../../../_/audit.mjs';

const list_get = defineEventHandler(
  (event) => apiResponse(event, async () => {
    const query = parseScoreRecordQuery(getQuery(event));
    return withDatabase(
      useRuntimeConfig(event).mysql,
      (connection) => inTransaction(connection, () => listScoreRecords(connection, query))
    );
  })
);

export { list_get as default };
//# sourceMappingURL=list.get.mjs.map
