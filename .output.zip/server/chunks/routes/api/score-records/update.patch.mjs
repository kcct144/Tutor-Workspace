import { c as defineEventHandler, e as apiResponse, w as withDatabase, u as useRuntimeConfig, i as inTransaction, r as requireActiveAuth } from '../../../_/nitro.mjs';
import { u as updateScoreRecord } from '../../../_/score-records.mjs';
import { p as parseScoreRecordWrite } from '../../../_/score-record-rules.mjs';
import { j as jsonBody } from '../../../_/json-body.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'mysql2/promise';
import 'node:url';
import '../../../_/contracts.mjs';
import '../../../_/audit.mjs';

const update_patch = defineEventHandler(
  (event) => apiResponse(event, async () => {
    const input = parseScoreRecordWrite(await jsonBody(event, 131072), true);
    return withDatabase(
      useRuntimeConfig(event).mysql,
      (db) => inTransaction(
        db,
        async () => updateScoreRecord(
          db,
          input,
          (await requireActiveAuth(db, event)).userId
        )
      )
    );
  })
);

export { update_patch as default };
//# sourceMappingURL=update.patch.mjs.map
