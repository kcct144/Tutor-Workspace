import { c as defineEventHandler, e as apiResponse, g as getQuery, A as ApiError, p as positiveId, w as withDatabase, u as useRuntimeConfig } from '../../../_/nitro.mjs';
import { f as findScoreRecord } from '../../../_/score-records.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'mysql2/promise';
import 'node:url';
import '../../../_/contracts.mjs';
import '../../../_/audit.mjs';

const detail_get = defineEventHandler(
  (event) => apiResponse(event, () => {
    const query = getQuery(event);
    if (Object.keys(query).some((key) => key !== "id"))
      throw new ApiError(400, "VALIDATION_ERROR", "\u67E5\u8BE2\u53C2\u6570\u65E0\u6548\u3002");
    const id = positiveId(query.id);
    return withDatabase(
      useRuntimeConfig(event).mysql,
      (connection) => findScoreRecord(connection, id)
    );
  })
);

export { detail_get as default };
//# sourceMappingURL=detail.get.mjs.map
