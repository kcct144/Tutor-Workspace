import { c as defineEventHandler, e as apiResponse, g as getQuery, w as withDatabase, u as useRuntimeConfig, i as inTransaction } from '../../../_/nitro.mjs';
import { s as scoreRecordSubjects } from '../../../_/score-records.mjs';
import { b as parseScoreRecordSubjectQuery } from '../../../_/score-record-rules.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'mysql2/promise';
import 'node:url';
import '../../../_/contracts.mjs';
import '../../../_/audit.mjs';

const subjects_get = defineEventHandler(
  (event) => apiResponse(event, async () => {
    const parsed = parseScoreRecordSubjectQuery(getQuery(event));
    const { page, pageSize, keyword } = parsed;
    return withDatabase(
      useRuntimeConfig(event).mysql,
      (connection) => inTransaction(
        connection,
        () => scoreRecordSubjects(connection, { page, pageSize, keyword })
      )
    );
  })
);

export { subjects_get as default };
//# sourceMappingURL=subjects.get.mjs.map
