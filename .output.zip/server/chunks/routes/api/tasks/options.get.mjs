import { c as defineEventHandler, e as apiResponse, w as withDatabase, u as useRuntimeConfig, g as getQuery } from '../../../_/nitro.mjs';
import { l as listTasks } from '../../../_/tasks.mjs';
import { a as parseTaskQuery } from '../../../_/task-rules.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'mysql2/promise';
import 'node:url';
import '../../../_/contracts.mjs';
import '../../../_/task-assignments.mjs';
import '../../../_/audit.mjs';

const options_get = defineEventHandler(
  (event) => apiResponse(
    event,
    () => withDatabase(
      useRuntimeConfig(event).mysql,
      (db) => listTasks(db, parseTaskQuery(getQuery(event), true), true)
    )
  )
);

export { options_get as default };
//# sourceMappingURL=options.get.mjs.map
