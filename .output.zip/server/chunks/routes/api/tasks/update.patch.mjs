import { c as defineEventHandler, e as apiResponse, w as withDatabase, u as useRuntimeConfig, i as inTransaction, r as requireActiveAuth } from '../../../_/nitro.mjs';
import { u as updateTask } from '../../../_/tasks.mjs';
import { c as parseTaskUpdate } from '../../../_/task-rules.mjs';
import { j as jsonBody } from '../../../_/json-body.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'mysql2/promise';
import 'node:url';
import '../../../_/contracts.mjs';
import '../../../_/task-assignments.mjs';
import '../../../_/audit.mjs';

const update_patch = defineEventHandler(
  (event) => apiResponse(event, async () => {
    const input = parseTaskUpdate(await jsonBody(event, 131072));
    const result = await withDatabase(
      useRuntimeConfig(event).mysql,
      (db) => inTransaction(
        db,
        async () => updateTask(db, input, (await requireActiveAuth(db, event)).userId)
      )
    );
    return result;
  })
);

export { update_patch as default };
//# sourceMappingURL=update.patch.mjs.map
