import { c as defineEventHandler, e as apiResponse, w as withDatabase, u as useRuntimeConfig, G as parseStudentId, g as getQuery } from '../../../_/nitro.mjs';
import { f as findTask } from '../../../_/tasks.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'mysql2/promise';
import 'node:url';
import '../../../_/contracts.mjs';
import '../../../_/task-assignments.mjs';
import '../../../_/audit.mjs';

const detail_get = defineEventHandler(
  (event) => apiResponse(
    event,
    () => withDatabase(
      useRuntimeConfig(event).mysql,
      (db) => findTask(db, parseStudentId(getQuery(event)))
    )
  )
);

export { detail_get as default };
//# sourceMappingURL=detail.get.mjs.map
