import { c as defineEventHandler, e as apiResponse, w as withDatabase, u as useRuntimeConfig, g as getQuery } from '../../../_/nitro.mjs';
import { t as taskSubjects } from '../../../_/tasks.mjs';
import { a as parseTaskQuery } from '../../../_/task-rules.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'mysql2/promise';
import 'node:url';
import '../../../_/contracts.mjs';
import '../../../_/task-assignments.mjs';
import '../../../_/audit.mjs';

const subjects_get = defineEventHandler(
  (event) => apiResponse(
    event,
    () => withDatabase(
      useRuntimeConfig(event).mysql,
      (db) => taskSubjects(db, parseTaskQuery(getQuery(event), true))
    )
  )
);

export { subjects_get as default };
//# sourceMappingURL=subjects.get.mjs.map
