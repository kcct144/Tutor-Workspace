import { c as defineEventHandler, e as apiResponse, w as withDatabase, u as useRuntimeConfig, i as inTransaction, r as requireActiveAuth } from '../../../_/nitro.mjs';
import { a as parseAssignmentCompletion, c as completeAssignment } from '../../../_/task-assignments.mjs';
import { j as jsonBody } from '../../../_/json-body.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'mysql2/promise';
import 'node:url';
import '../../../_/audit.mjs';
import '../../../_/contracts.mjs';

const completion_patch = defineEventHandler(
  (event) => apiResponse(event, async () => {
    const input = parseAssignmentCompletion(await jsonBody(event, 16384));
    return withDatabase(
      useRuntimeConfig(event).mysql,
      (db) => inTransaction(db, async () => {
        const auth = await requireActiveAuth(db, event);
        return completeAssignment(db, input, auth.userId);
      })
    );
  })
);

export { completion_patch as default };
//# sourceMappingURL=completion.patch.mjs.map
