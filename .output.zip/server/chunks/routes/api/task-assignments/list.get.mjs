import { c as defineEventHandler, e as apiResponse, g as getQuery, w as withDatabase, u as useRuntimeConfig, i as inTransaction } from '../../../_/nitro.mjs';
import { e as parseAssignmentQuery, l as listAssignments } from '../../../_/task-assignments.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'mysql2/promise';
import 'node:url';
import '../../../_/audit.mjs';
import '../../../_/contracts.mjs';

const list_get = defineEventHandler(
  (event) => apiResponse(event, async () => {
    const query = parseAssignmentQuery(getQuery(event));
    return withDatabase(
      useRuntimeConfig(event).mysql,
      (db) => inTransaction(db, () => listAssignments(db, query))
    );
  })
);

export { list_get as default };
//# sourceMappingURL=list.get.mjs.map
