import { c as defineEventHandler, e as apiResponse, w as withDatabase, u as useRuntimeConfig, i as inTransaction, r as requireActiveAuth, f as setResponseStatus } from '../../../_/nitro.mjs';
import { b as parseAssignmentBatch, d as createAssignmentBatch } from '../../../_/task-assignments.mjs';
import { j as jsonBody } from '../../../_/json-body.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'mysql2/promise';
import 'node:url';
import '../../../_/audit.mjs';
import '../../../_/contracts.mjs';

const createBatch_post = defineEventHandler(
  (event) => apiResponse(event, async () => {
    const input = parseAssignmentBatch(await jsonBody(event, 16384));
    const result = await withDatabase(
      useRuntimeConfig(event).mysql,
      (db) => inTransaction(
        db,
        async () => createAssignmentBatch(
          db,
          input,
          (await requireActiveAuth(db, event)).userId
        )
      )
    );
    setResponseStatus(event, 201);
    return result;
  })
);

export { createBatch_post as default };
//# sourceMappingURL=create-batch.post.mjs.map
