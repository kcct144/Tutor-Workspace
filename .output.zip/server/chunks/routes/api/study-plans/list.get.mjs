import { c as defineEventHandler, e as apiResponse, g as getQuery, w as withDatabase, u as useRuntimeConfig, i as inTransaction } from '../../../_/nitro.mjs';
import { l as listPlans } from '../../../_/study-plans.mjs';
import { p as parsePlanQuery } from '../../../_/study-plan-rules.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'mysql2/promise';
import 'node:url';
import '../../../_/contracts.mjs';
import '../../../_/task-assignments.mjs';
import '../../../_/audit.mjs';

const list_get = defineEventHandler(
  (event) => apiResponse(event, async () => {
    const query = parsePlanQuery(getQuery(event));
    return withDatabase(
      useRuntimeConfig(event).mysql,
      (db) => inTransaction(db, () => listPlans(db, query))
    );
  })
);

export { list_get as default };
//# sourceMappingURL=list.get.mjs.map
