import { c as defineEventHandler, e as apiResponse, w as withDatabase, u as useRuntimeConfig, i as inTransaction, r as requireActiveAuth } from '../../../_/nitro.mjs';
import { u as updatePlan } from '../../../_/study-plans.mjs';
import { a as parsePlanUpdate } from '../../../_/study-plan-rules.mjs';
import { j as jsonBody } from '../../../_/json-body.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'mysql2/promise';
import 'node:url';
import '../../../_/contracts.mjs';
import '../../../_/task-assignments.mjs';
import '../../../_/audit.mjs';

const update_patch = defineEventHandler(
  (event) => apiResponse(event, async () => {
    const input = parsePlanUpdate(await jsonBody(event, 2097152));
    return withDatabase(
      useRuntimeConfig(event).mysql,
      (db) => inTransaction(db, async () => {
        await requireActiveAuth(db, event);
        return updatePlan(db, input);
      })
    );
  })
);

export { update_patch as default };
//# sourceMappingURL=update.patch.mjs.map
