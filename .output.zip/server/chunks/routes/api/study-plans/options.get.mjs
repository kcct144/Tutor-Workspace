import { c as defineEventHandler, e as apiResponse, w as withDatabase, u as useRuntimeConfig, g as getQuery } from '../../../_/nitro.mjs';
import { b as listPlanOptions } from '../../../_/study-plans.mjs';
import { p as parsePlanQuery } from '../../../_/study-plan-rules.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'mysql2/promise';
import 'node:url';
import '../../../_/contracts.mjs';
import '../../../_/task-assignments.mjs';
import '../../../_/audit.mjs';

const options_get = defineEventHandler(
  (event) => apiResponse(
    event,
    () => withDatabase(
      useRuntimeConfig(event).mysql,
      (db) => listPlanOptions(db, parsePlanQuery(getQuery(event)))
    )
  )
);

export { options_get as default };
//# sourceMappingURL=options.get.mjs.map
