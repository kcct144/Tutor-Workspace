import { c as defineEventHandler, e as apiResponse, n as currentAuth, w as withDatabase, u as useRuntimeConfig, D as revokeSession, E as clearBrowserSessionCookies } from '../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'mysql2/promise';
import 'node:url';

const logout_post = defineEventHandler(
  (event) => apiResponse(event, async () => {
    const auth = currentAuth(event);
    await withDatabase(
      useRuntimeConfig(event).mysql,
      (db) => revokeSession(db, auth.sessionId)
    );
    clearBrowserSessionCookies(event);
    return { loggedOut: true };
  })
);

export { logout_post as default };
//# sourceMappingURL=logout.post.mjs.map
