import { x as assertApprovedDatabase, m as executeWrite, A as ApiError, c as defineEventHandler, e as apiResponse, y as assertLoopbackRequest, z as sameOrigin, w as withDatabase, u as useRuntimeConfig, B as createBrowserSession, C as setBrowserSessionCookies } from '../../../_/nitro.mjs';
import { timingSafeEqual, argon2 } from 'node:crypto';
import { j as jsonBody } from '../../../_/json-body.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'mysql2/promise';
import 'node:url';

const argon2Parameters = {
  memory: 19456,
  passes: 2,
  parallelism: 1,
  tagLength: 32
};
class AuthValidationError extends Error {
  constructor(message) {
    super(message);
    this.name = "AuthValidationError";
  }
}
function invalid(message) {
  throw new AuthValidationError(message);
}
function normalizeUsername(value) {
  if (typeof value !== "string") invalid("\u8D26\u53F7\u683C\u5F0F\u65E0\u6548\u3002");
  const username = value.trim().toLowerCase();
  if (!/^[a-z0-9._-]{3,64}$/.test(username))
    invalid("\u8D26\u53F7\u987B\u4E3A3\u81F364\u4F4D\u5C0F\u5199ASCII\u5B57\u6BCD\u3001\u6570\u5B57\u3001\u70B9\u3001\u4E0B\u5212\u7EBF\u6216\u8FDE\u5B57\u7B26\u3002");
  return username;
}
function encodePhcPart(value) {
  return value.toString("base64").replace(/=+$/u, "");
}
function decodePhcPart(value) {
  if (!/^[A-Za-z0-9+/]+$/u.test(value)) return null;
  try {
    const decoded = Buffer.from(value, "base64");
    return encodePhcPart(decoded) === value ? decoded : null;
  } catch {
    return null;
  }
}
function parsePasswordHash(value) {
  const match = /^\$argon2id\$v=19\$m=(\d+),t=(\d+),p=(\d+)\$([A-Za-z0-9+/]+)\$([A-Za-z0-9+/]+)$/u.exec(
    value
  );
  if (!match) return null;
  if (Number(match[1]) !== argon2Parameters.memory || Number(match[2]) !== argon2Parameters.passes || Number(match[3]) !== argon2Parameters.parallelism)
    return null;
  const salt = decodePhcPart(match[4]);
  const tag = decodePhcPart(match[5]);
  if (!salt || !tag || salt.length < 16 || tag.length !== argon2Parameters.tagLength)
    return null;
  return { salt, tag };
}
function deriveArgon2id(password, salt) {
  return new Promise((resolve, reject) => {
    argon2(
      "argon2id",
      {
        message: Buffer.from(password, "utf8"),
        nonce: salt,
        ...argon2Parameters
      },
      (error, tag) => {
        if (error) reject(error);
        else resolve(tag);
      }
    );
  });
}
async function verifyPassword(password, storedHash) {
  const parsed = parsePasswordHash(storedHash);
  if (!parsed) return false;
  const actual = await deriveArgon2id(password, parsed.salt);
  return timingSafeEqual(actual, parsed.tag);
}

const genericLoginError = () => new ApiError(401, "INVALID_CREDENTIALS", "\u8D26\u53F7\u6216\u5BC6\u7801\u9519\u8BEF\u3002");
function loginObject(value) {
  if (!value || typeof value !== "object" || Array.isArray(value))
    throw new ApiError(400, "VALIDATION_ERROR", "\u767B\u5F55\u8BF7\u6C42\u683C\u5F0F\u65E0\u6548\u3002");
  const input = value;
  if (Object.keys(input).length !== 2 || !Object.hasOwn(input, "username") || !Object.hasOwn(input, "password") || typeof input.username !== "string" || typeof input.password !== "string" || Buffer.byteLength(input.password, "utf8") > 512)
    throw new ApiError(400, "VALIDATION_ERROR", "\u767B\u5F55\u8BF7\u6C42\u683C\u5F0F\u65E0\u6548\u3002");
  return { username: input.username, password: input.password };
}
async function genericPasswordWork(password) {
  const dummyHash = "$argon2id$v=19$m=19456,t=2,p=1$MDEyMzQ1Njc4OWFiY2RlZg$AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA";
  await verifyPassword(password, dummyHash);
}
async function authenticateAccount(connection, value, afterAuthenticated) {
  const input = loginObject(value);
  let username;
  try {
    username = normalizeUsername(input.username);
  } catch {
    await genericPasswordWork(input.password);
    throw genericLoginError();
  }
  await assertApprovedDatabase(connection);
  await connection.beginTransaction();
  try {
    await assertApprovedDatabase(connection);
    const [rows] = await connection.execute(
      "SELECT a.user_id,u.name,a.username,a.password_hash,a.role,a.status,a.must_change_password,a.failed_login_count,a.failed_window_started_at,a.locked_until,(a.locked_until>UTC_TIMESTAMP(3)) AS is_locked,(a.failed_window_started_at>=DATE_SUB(UTC_TIMESTAMP(3), INTERVAL 15 MINUTE)) AS in_failure_window FROM user_accounts a INNER JOIN users u ON u.id=a.user_id WHERE a.username=? LIMIT 1 FOR UPDATE",
      [username]
    );
    const account = rows[0];
    const passwordMatches = account ? await verifyPassword(input.password, account.password_hash) : (await genericPasswordWork(input.password), false);
    if (!account || !passwordMatches || account.status !== "enabled" || Number(account.is_locked) === 1) {
      if (account && account.status === "enabled" && !Number(account.is_locked)) {
        const failures = Number(account.in_failure_window) ? Number(account.failed_login_count) + 1 : 1;
        await executeWrite(
          connection,
          "UPDATE user_accounts SET failed_login_count=?,failed_window_started_at=IF(?,failed_window_started_at,UTC_TIMESTAMP(3)),locked_until=IF(? >= 5,DATE_ADD(UTC_TIMESTAMP(3), INTERVAL 15 MINUTE),NULL) WHERE user_id=?",
          [
            failures,
            Number(account.in_failure_window),
            failures,
            String(account.user_id)
          ]
        );
      }
      await connection.commit();
      throw genericLoginError();
    }
    await executeWrite(
      connection,
      "UPDATE user_accounts SET failed_login_count=0,failed_window_started_at=NULL,locked_until=NULL,last_login_at=UTC_TIMESTAMP(3) WHERE user_id=?",
      [String(account.user_id)]
    );
    const authenticated = {
      userId: String(account.user_id),
      name: account.name,
      username: account.username,
      role: account.role,
      mustChangePassword: Number(account.must_change_password) === 1
    };
    await (afterAuthenticated == null ? void 0 : afterAuthenticated(authenticated));
    await assertApprovedDatabase(connection);
    await connection.commit();
    return authenticated;
  } catch (error) {
    await connection.rollback().catch(() => {
    });
    throw error;
  }
}

const login_post = defineEventHandler(
  (event) => apiResponse(event, async () => {
    try {
      assertLoopbackRequest(event);
    } catch {
      throw new ApiError(403, "ORIGIN_INVALID", "\u4EC5\u5141\u8BB8\u672C\u673A\u8BBF\u95EE\u3002");
    }
    if (!sameOrigin(event))
      throw new ApiError(403, "CSRF_INVALID", "\u8BF7\u6C42\u6765\u6E90\u6821\u9A8C\u5931\u8D25\u3002");
    const credentials = await jsonBody(event, 2048);
    const result = await withDatabase(
      useRuntimeConfig(event).mysql,
      async (db) => {
        let tokens;
        const account = await authenticateAccount(
          db,
          credentials,
          async (active) => {
            tokens = await createBrowserSession(db, active.userId);
          }
        );
        if (!tokens) throw new Error("\u4F1A\u8BDD\u521B\u5EFA\u672A\u5B8C\u6210\u3002");
        return { account, tokens };
      }
    );
    setBrowserSessionCookies(
      event,
      result.tokens.sessionToken,
      result.tokens.csrfToken
    );
    return {
      id: result.account.userId,
      username: result.account.username,
      name: result.account.name,
      role: result.account.role,
      mustChangePassword: result.account.mustChangePassword
    };
  })
);

export { login_post as default };
//# sourceMappingURL=login.post.mjs.map
