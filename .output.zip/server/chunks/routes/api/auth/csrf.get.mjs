import { c as defineEventHandler, e as apiResponse, n as currentAuth, w as withDatabase, u as useRuntimeConfig, o as rotateSessionCsrf, q as setCookie, v as csrfCookieName } from '../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'mysql2/promise';
import 'node:url';

const csrf_get = defineEventHandler(
  (event) => apiResponse(event, async () => {
    const auth = currentAuth(event);
    const csrfToken = await withDatabase(
      useRuntimeConfig(event).mysql,
      (db) => rotateSessionCsrf(db, auth.sessionId)
    );
    setCookie(event, csrfCookieName, csrfToken, {
      path: "/",
      sameSite: "strict",
      secure: false,
      httpOnly: false,
      maxAge: 7 * 24 * 60 * 60
    });
    return { rotated: true };
  })
);

export { csrf_get as default };
//# sourceMappingURL=csrf.get.mjs.map
