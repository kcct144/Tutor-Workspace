import { c as defineEventHandler, e as apiResponse, n as currentAuth } from '../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'mysql2/promise';
import 'node:url';

const me_get = defineEventHandler(
  (event) => apiResponse(event, async () => {
    const auth = currentAuth(event);
    return {
      id: auth.userId,
      username: auth.username,
      name: auth.name,
      role: auth.role,
      mustChangePassword: auth.mustChangePassword
    };
  })
);

export { me_get as default };
//# sourceMappingURL=me.get.mjs.map
