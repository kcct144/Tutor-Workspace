import { c as defineEventHandler, e as apiResponse, g as getQuery, w as withDatabase, u as useRuntimeConfig, i as inTransaction } from '../../../_/nitro.mjs';
import { p as parseAttendanceMonthQuery, l as listAttendanceMonth } from '../../../_/attendance.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'mysql2/promise';
import 'node:url';
import '../../../_/contracts.mjs';
import '../../../_/audit.mjs';

const month_get = defineEventHandler(
  (event) => apiResponse(event, async () => {
    const query = parseAttendanceMonthQuery(getQuery(event));
    return withDatabase(
      useRuntimeConfig(event).mysql,
      (connection) => inTransaction(connection, () => listAttendanceMonth(connection, query))
    );
  })
);

export { month_get as default };
//# sourceMappingURL=month.get.mjs.map
