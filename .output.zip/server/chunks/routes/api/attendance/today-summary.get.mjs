import { c as defineEventHandler, e as apiResponse, g as getQuery, w as withDatabase, u as useRuntimeConfig, i as inTransaction } from '../../../_/nitro.mjs';
import { b as parseAttendanceSummaryQuery, c as attendanceTodaySummary } from '../../../_/attendance.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'mysql2/promise';
import 'node:url';
import '../../../_/contracts.mjs';
import '../../../_/audit.mjs';

const todaySummary_get = defineEventHandler(
  (event) => apiResponse(event, async () => {
    const query = parseAttendanceSummaryQuery(getQuery(event));
    return withDatabase(
      useRuntimeConfig(event).mysql,
      (connection) => inTransaction(
        connection,
        () => attendanceTodaySummary(connection, query, query.period)
      )
    );
  })
);

export { todaySummary_get as default };
//# sourceMappingURL=today-summary.get.mjs.map
