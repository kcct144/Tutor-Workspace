import { c as defineEventHandler, e as apiResponse, w as withDatabase, u as useRuntimeConfig, i as inTransaction, r as requireActiveAuth, f as setResponseStatus } from '../../../_/nitro.mjs';
import { a as parseAttendanceCellWrite, s as setAttendanceCell } from '../../../_/attendance.mjs';
import { j as jsonBody } from '../../../_/json-body.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'mysql2/promise';
import 'node:url';
import '../../../_/contracts.mjs';
import '../../../_/audit.mjs';

const record_put = defineEventHandler(
  (event) => apiResponse(event, async () => {
    const input = parseAttendanceCellWrite(await jsonBody(event, 32768));
    const result = await withDatabase(
      useRuntimeConfig(event).mysql,
      (db) => inTransaction(
        db,
        async () => setAttendanceCell(
          db,
          input,
          (await requireActiveAuth(db, event)).userId
        )
      )
    );
    if (input.expectedVersion === null) setResponseStatus(event, 201);
    return result;
  })
);

export { record_put as default };
//# sourceMappingURL=record.put.mjs.map
