import { c as defineEventHandler, e as apiResponse, F as parseContractWrite, w as withDatabase, u as useRuntimeConfig, i as inTransaction, r as requireActiveAuth, f as setResponseStatus } from '../../../_/nitro.mjs';
import { c as createContract } from '../../../_/contracts.mjs';
import { j as jsonBody } from '../../../_/json-body.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'mysql2/promise';
import 'node:url';

const create_post = defineEventHandler(
  (event) => apiResponse(event, async () => {
    const input = parseContractWrite(await jsonBody(event, 16384));
    const result = await withDatabase(
      useRuntimeConfig(event).mysql,
      (connection) => inTransaction(
        connection,
        async () => createContract(
          connection,
          input,
          (await requireActiveAuth(connection, event)).userId
        )
      )
    );
    setResponseStatus(event, 201);
    return result;
  })
);

export { create_post as default };
//# sourceMappingURL=create.post.mjs.map
