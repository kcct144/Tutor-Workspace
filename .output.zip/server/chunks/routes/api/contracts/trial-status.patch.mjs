import { c as defineEventHandler, e as apiResponse, I as parseTrialTermination, w as withDatabase, u as useRuntimeConfig, i as inTransaction, r as requireActiveAuth } from '../../../_/nitro.mjs';
import { t as terminateTrialContract } from '../../../_/contracts.mjs';
import { j as jsonBody } from '../../../_/json-body.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'mysql2/promise';
import 'node:url';

const trialStatus_patch = defineEventHandler(
  (event) => apiResponse(event, async () => {
    const input = parseTrialTermination(await jsonBody(event, 2048));
    return withDatabase(
      useRuntimeConfig(event).mysql,
      (connection) => inTransaction(
        connection,
        async () => terminateTrialContract(
          connection,
          input.id,
          input.expectedVersion,
          (await requireActiveAuth(connection, event)).userId
        )
      )
    );
  })
);

export { trialStatus_patch as default };
//# sourceMappingURL=trial-status.patch.mjs.map
