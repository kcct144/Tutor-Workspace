import { c as defineEventHandler, e as apiResponse, H as parseContractQuery, g as getQuery, w as withDatabase, u as useRuntimeConfig, i as inTransaction } from '../../../_/nitro.mjs';
import { b as contractSubjects } from '../../../_/contracts.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'mysql2/promise';
import 'node:url';

const subjects_get = defineEventHandler(
  (event) => apiResponse(event, async () => {
    const query = parseContractQuery(getQuery(event), true);
    return withDatabase(
      useRuntimeConfig(event).mysql,
      (connection) => inTransaction(connection, () => contractSubjects(connection, query))
    );
  })
);

export { subjects_get as default };
//# sourceMappingURL=subjects.get.mjs.map
