import { c as defineEventHandler, e as apiResponse, H as parseContractQuery, g as getQuery, w as withDatabase, u as useRuntimeConfig, i as inTransaction } from '../../../_/nitro.mjs';
import { a as listContracts } from '../../../_/contracts.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'mysql2/promise';
import 'node:url';

const list_get = defineEventHandler(
  (event) => apiResponse(event, async () => {
    const query = parseContractQuery(getQuery(event));
    return withDatabase(
      useRuntimeConfig(event).mysql,
      (connection) => inTransaction(connection, () => listContracts(connection, query))
    );
  })
);

export { list_get as default };
//# sourceMappingURL=list.get.mjs.map
