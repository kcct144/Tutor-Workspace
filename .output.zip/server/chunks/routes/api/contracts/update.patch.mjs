import { c as defineEventHandler, e as apiResponse, F as parseContractWrite, w as withDatabase, u as useRuntimeConfig, i as inTransaction, r as requireActiveAuth } from '../../../_/nitro.mjs';
import { u as updateContract } from '../../../_/contracts.mjs';
import { j as jsonBody } from '../../../_/json-body.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'mysql2/promise';
import 'node:url';

const update_patch = defineEventHandler(
  (event) => apiResponse(event, async () => {
    const input = parseContractWrite(await jsonBody(event, 16384), true);
    return withDatabase(
      useRuntimeConfig(event).mysql,
      (connection) => inTransaction(
        connection,
        async () => updateContract(
          connection,
          input,
          (await requireActiveAuth(connection, event)).userId
        )
      )
    );
  })
);

export { update_patch as default };
//# sourceMappingURL=update.patch.mjs.map
