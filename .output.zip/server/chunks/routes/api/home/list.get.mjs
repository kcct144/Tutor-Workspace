import { l as shanghaiToday, c as defineEventHandler, e as apiResponse, g as getQuery, w as withDatabase, u as useRuntimeConfig, i as inTransaction } from '../../../_/nitro.mjs';
import { s as studentAssignmentSummaries, p as parseHomeQuery } from '../../../_/task-assignments.mjs';
import { s as studentContractAggregates } from '../../../_/contracts.mjs';
import { s as studentPlanTags } from '../../../_/study-plans.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'mysql2/promise';
import 'node:url';
import '../../../_/audit.mjs';

async function listHome(db, query, today = shanghaiToday()) {
  const where = " WHERE status='\u5728\u8BFB'" + (query.grade ? " AND grade=?" : "");
  const values = query.grade ? [query.grade] : [];
  const [active] = await db.execute(
    "SELECT COUNT(*) AS total FROM students WHERE status='\u5728\u8BFB' LIMIT 1"
  );
  const [counts] = await db.execute(
    "SELECT COUNT(*) AS total FROM students" + where + " LIMIT 1",
    values
  );
  const [rows] = await db.execute(
    "SELECT id,name,grade,school FROM students" + where + " ORDER BY id DESC LIMIT ? OFFSET ?",
    [...values, query.pageSize, (query.page - 1) * query.pageSize]
  );
  const ids = rows.map((row) => String(row.id));
  const contracts = await studentContractAggregates(db, ids, today), plans = await studentPlanTags(db, ids), assignments = await studentAssignmentSummaries(db, ids, today);
  const items = rows.map((row) => {
    var _a, _b, _c;
    const id = String(row.id), contract = (_a = contracts.get(id)) != null ? _a : { subjects: [], expiryDate: null }, tasks = (_b = assignments.get(id)) != null ? _b : {
      pendingTasks: [],
      completedTasks: [],
      pendingCount: 0,
      completedCount: 0
    };
    return {
      id,
      name: row.name,
      grade: row.grade,
      school: row.school,
      status: "\u5728\u8BFB",
      ...contract,
      expiresInDays: contract.expiryDate === null ? null : Math.round(
        (Date.parse(contract.expiryDate + "T00:00:00Z") - Date.parse(today + "T00:00:00Z")) / 864e5
      ),
      plans: (_c = plans.get(id)) != null ? _c : [],
      ...tasks,
      pendingRemaining: Math.max(
        0,
        tasks.pendingCount - tasks.pendingTasks.length
      ),
      completedRemaining: Math.max(
        0,
        tasks.completedCount - tasks.completedTasks.length
      )
    };
  });
  return {
    items,
    total: Number(counts[0].total),
    page: query.page,
    pageSize: query.pageSize,
    activeStudents: Number(active[0].total),
    asOfDate: today
  };
}

const list_get = defineEventHandler(
  (event) => apiResponse(event, async () => {
    const query = parseHomeQuery(getQuery(event));
    return withDatabase(
      useRuntimeConfig(event).mysql,
      (db) => inTransaction(db, () => listHome(db, query))
    );
  })
);

export { list_get as default };
//# sourceMappingURL=list.get.mjs.map
