import { c as defineEventHandler, J as setResponseHeader } from '../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'mysql2/promise';
import 'node:url';

const health_get = defineEventHandler((event) => {
  setResponseHeader(event, "Cache-Control", "no-store");
  return {
    status: "ok",
    msg: "\u6210\u529F",
    data: { app: "ok" }
  };
});

export { health_get as default };
//# sourceMappingURL=health.get.mjs.map
