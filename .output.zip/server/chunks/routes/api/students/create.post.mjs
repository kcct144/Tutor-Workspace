import { c as defineEventHandler, e as apiResponse, w as withDatabase, u as useRuntimeConfig, i as inTransaction, r as requireActiveAuth, f as setResponseStatus } from '../../../_/nitro.mjs';
import { c as createStudent } from '../../../_/student-profile.mjs';
import { p as parseStudentCreate } from '../../../_/students.mjs';
import { j as jsonBody } from '../../../_/json-body.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'mysql2/promise';
import 'node:url';
import '../../../_/contracts.mjs';
import '../../../_/study-plans.mjs';
import '../../../_/task-assignments.mjs';
import '../../../_/audit.mjs';

const create_post = defineEventHandler(
  (event) => apiResponse(event, async () => {
    const input = parseStudentCreate(await jsonBody(event, 16384));
    const result = await withDatabase(
      useRuntimeConfig(event).mysql,
      (db) => inTransaction(db, async () => {
        await requireActiveAuth(db, event);
        return createStudent(db, input);
      })
    );
    setResponseStatus(event, 201);
    return result;
  })
);

export { create_post as default };
//# sourceMappingURL=create.post.mjs.map
