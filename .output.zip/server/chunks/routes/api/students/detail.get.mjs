import { c as defineEventHandler, e as apiResponse, G as parseStudentId, g as getQuery, w as withDatabase, u as useRuntimeConfig } from '../../../_/nitro.mjs';
import { f as findStudent } from '../../../_/students.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'mysql2/promise';
import 'node:url';
import '../../../_/contracts.mjs';
import '../../../_/study-plans.mjs';
import '../../../_/task-assignments.mjs';
import '../../../_/audit.mjs';

const detail_get = defineEventHandler(
  (event) => apiResponse(event, async () => {
    const id = parseStudentId(getQuery(event));
    return withDatabase(
      useRuntimeConfig(event).mysql,
      (connection) => findStudent(connection, id)
    );
  })
);

export { detail_get as default };
//# sourceMappingURL=detail.get.mjs.map
