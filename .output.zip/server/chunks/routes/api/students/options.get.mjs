import { c as defineEventHandler, e as apiResponse, g as getQuery, N as parseStudentOptionIds, w as withDatabase, u as useRuntimeConfig, L as parseStudentQuery, i as inTransaction } from '../../../_/nitro.mjs';
import { s as studentOptionsByIds, l as listStudents } from '../../../_/students.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'mysql2/promise';
import 'node:url';
import '../../../_/contracts.mjs';
import '../../../_/study-plans.mjs';
import '../../../_/task-assignments.mjs';
import '../../../_/audit.mjs';

const options_get = defineEventHandler(
  (event) => apiResponse(event, async () => {
    const input = getQuery(event);
    if (input.ids !== void 0) {
      const ids = parseStudentOptionIds(input);
      return withDatabase(
        useRuntimeConfig(event).mysql,
        (db) => studentOptionsByIds(db, ids)
      );
    }
    const query = parseStudentQuery(input, true);
    return withDatabase(
      useRuntimeConfig(event).mysql,
      (connection) => inTransaction(connection, () => listStudents(connection, query, true))
    );
  })
);

export { options_get as default };
//# sourceMappingURL=options.get.mjs.map
