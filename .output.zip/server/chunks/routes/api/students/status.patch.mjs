import { c as defineEventHandler, e as apiResponse, w as withDatabase, u as useRuntimeConfig, i as inTransaction, r as requireActiveAuth } from '../../../_/nitro.mjs';
import { u as updateStudent } from '../../../_/student-profile.mjs';
import { a as parseStudentStatus } from '../../../_/students.mjs';
import { j as jsonBody } from '../../../_/json-body.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'mysql2/promise';
import 'node:url';
import '../../../_/contracts.mjs';
import '../../../_/study-plans.mjs';
import '../../../_/task-assignments.mjs';
import '../../../_/audit.mjs';

const status_patch = defineEventHandler(
  (event) => apiResponse(event, async () => {
    const input = parseStudentStatus(await jsonBody(event, 16384));
    const result = await withDatabase(
      useRuntimeConfig(event).mysql,
      (db) => inTransaction(db, async () => {
        await requireActiveAuth(db, event);
        return updateStudent(db, input);
      })
    );
    return result;
  })
);

export { status_patch as default };
//# sourceMappingURL=status.patch.mjs.map
