import { c as defineEventHandler, e as apiResponse, w as withDatabase, u as useRuntimeConfig, G as parseStudentId, g as getQuery } from '../../../_/nitro.mjs';
import { a as studentPlanProgress } from '../../../_/study-plans.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'mysql2/promise';
import 'node:url';
import '../../../_/contracts.mjs';
import '../../../_/task-assignments.mjs';
import '../../../_/audit.mjs';

const planProgress_get = defineEventHandler(
  (event) => apiResponse(
    event,
    () => withDatabase(
      useRuntimeConfig(event).mysql,
      (db) => studentPlanProgress(db, parseStudentId(getQuery(event)))
    )
  )
);

export { planProgress_get as default };
//# sourceMappingURL=plan-progress.get.mjs.map
